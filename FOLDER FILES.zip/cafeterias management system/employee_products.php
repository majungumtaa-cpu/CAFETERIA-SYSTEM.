<?php
// employee_products.php - READ-ONLY access
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    header('Location: employee_login.php');
    exit();
}

$employee_name = $_SESSION['full_name'];

// Get all products - READ-ONLY for employees
$products = mysqli_query($conn, "
    SELECT p.*, mc.category_name 
    FROM product p 
    JOIN menu_category mc ON p.category_id = mc.id 
    ORDER BY p.product_name ASC
    LIMIT 500
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Employee Portal</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <?php include 'employee_sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-box"></i> Products</h1>
                <span>View all available products</span>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2>Available Products</h2>
                    <span><?php echo mysqli_num_rows($products); ?> products</span>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($product = mysqli_fetch_assoc($products)): 
                                $stock_status = $product['quantity'] > 10 ? 'In Stock' : ($product['quantity'] > 0 ? 'Low Stock' : 'Out of Stock');
                                $stock_color = $product['quantity'] > 10 ? '#2ecc71' : ($product['quantity'] > 0 ? '#f39c12' : '#e74c3c');
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($product['product_name']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                                <td>
                                    <strong style="color: #E07B39;">
                                        TZS <?php echo number_format($product['price'], 2); ?>
                                    </strong>
                                </td>
                                <td><?php echo $product['quantity']; ?> units</td>
                                <td>
                                    <span style="color: <?php echo $stock_color; ?>; font-weight: 600;">
                                        <i class="fas fa-circle" style="font-size: 0.6rem;"></i>
                                        <?php echo $stock_status; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($products) == 0): ?>
                            <tr>
                                <td colspan="5" style="text-align: center; padding: 40px;">
                                    <i class="fas fa-inbox" style="font-size: 2rem; color: #ddd;"></i>
                                    <p style="color: #999; margin-top: 10px;">No products available</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
