<?php
// admin_dashboard.php (Admin Dashboard)
require_once 'config.php';
check_login();

// Prevent employees from accessing admin dashboard
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: employee_dashboard.php');
    exit();
}

// Get statistics
$today = date('Y-m-d');
$stats = array();

// Total orders today
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM `order` WHERE DATE(order_date) = '$today'");
$row = mysqli_fetch_assoc($result);
$stats['orders_today'] = $row['count'];

// Total revenue today
$result = mysqli_query($conn, "
    SELECT SUM(od.quantity * p.price) as revenue
    FROM `order` o
    JOIN order_detail od ON o.id = od.order_id
    JOIN product p ON od.product_id = p.id
    WHERE DATE(o.order_date) = '$today'
");
$row = mysqli_fetch_assoc($result);
$stats['revenue_today'] = $row['revenue'] ?? 0;

// Total customers
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM customer");
$row = mysqli_fetch_assoc($result);
$stats['total_customers'] = $row['count'];

// Low stock products
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM product WHERE quantity < 10");
$row = mysqli_fetch_assoc($result);
$stats['low_stock'] = $row['count'];

// Recent orders
$recent_orders = mysqli_query($conn, "
    SELECT o.id, c.full_name, o.order_date,
           SUM(od.quantity * p.price) as total
    FROM `order` o
    JOIN customer c ON o.customer_id = c.id
    JOIN order_detail od ON o.id = od.order_id
    JOIN product p ON od.product_id = p.id
    GROUP BY o.id
    ORDER BY o.order_date DESC
    LIMIT 5
");

// Low stock items
$low_stock_items = mysqli_query($conn, "
    SELECT id, product_name, quantity
    FROM product
    WHERE quantity < 10
    ORDER BY quantity ASC
    LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: white;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container">
        <?php include 'sidebar.php'; ?>

        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-tachometer-alt"></i> Admin Dashboard</h1>
                <span>Welcome, <?php echo $_SESSION['full_name']; ?>!</span>
            </div>

            <!-- Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="color: #E07B39;">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stat-value"><?php echo $stats['orders_today']; ?></div>
                    <div class="stat-label">Today's Orders</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="color: #2ecc71;">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-value">TZS <?php echo number_format($stats['revenue_today'], 2); ?></div>
                    <div class="stat-label">Today's Revenue</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="color: #9b59b6;">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-value"><?php echo $stats['total_customers']; ?></div>
                    <div class="stat-label">Total Customers</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="color: #e74c3c;">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="stat-value"><?php echo $stats['low_stock']; ?></div>
                    <div class="stat-label">Low Stock Items</div>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-history"></i> Recent Orders</h2>
                    <a href="orders.php" class="btn btn-primary">View All</a>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Date</th>
                                <th>Total</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($order = mysqli_fetch_assoc($recent_orders)): ?>
                            <tr>
                                <td>#<?php echo str_pad($order['id'], 5, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($order['full_name']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                                <td>TZS <?php echo number_format($order['total'], 2); ?></td>
                                <td><span class="status-badge status-active">Completed</span></td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($recent_orders) == 0): ?>
                            <tr>
                                <td colspan="5" style="text-align: center;">No orders today</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Low Stock Alert -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-exclamation-circle"></i> Low Stock Alert</h2>
                    <a href="products.php" class="btn btn-primary">Manage Inventory</a>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Stock Quantity</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($item = mysqli_fetch_assoc($low_stock_items)):
                                $status_class = $item['quantity'] < 5 ? 'status-inactive' : 'status-pending';
                                $status_text = $item['quantity'] < 5 ? 'Critical' : 'Low';
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span></td>
                                <td>
                                    <a href="edit_product.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-edit"></i> Update
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($low_stock_items) == 0): ?>
                            <tr>
                                <td colspan="4" style="text-align: center;">All products are well stocked</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>