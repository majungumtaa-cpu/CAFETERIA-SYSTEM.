<?php
// reservations.php - Simplified without services
require_once 'config.php';
check_login();

// Prevent employees from accessing this page
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: employee_dashboard.php');
    exit();
}

$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_reservation'])) {
        $customer_id = intval($_POST['customer_id']);
        $reservation_date = mysqli_real_escape_string($conn, $_POST['reservation_date']);
        $table_number = mysqli_real_escape_string($conn, $_POST['table_number'] ?? '');
        $notes = mysqli_real_escape_string($conn, $_POST['notes'] ?? '');
        
        // Check for duplicate reservation for same customer on same date
        $check_sql = "SELECT id FROM reservation 
                     WHERE customer_id = $customer_id 
                     AND reservation_date = '$reservation_date'";
        $check_result = mysqli_query($conn, $check_sql);
        
        if (mysqli_num_rows($check_result) > 0) {
            $message = 'Customer already has a reservation for this date!';
            $message_type = 'error';
        } else {
            // Insert reservation without service_id
            $sql = "INSERT INTO reservation (customer_id, reservation_date, table_number, notes) 
                    VALUES ($customer_id, '$reservation_date', '$table_number', '$notes')";
            
            if (mysqli_query($conn, $sql)) {
                $message = 'Reservation added successfully!';
                $message_type = 'success';
            } else {
                $message = 'Error adding reservation: ' . mysqli_error($conn);
                $message_type = 'error';
            }
        }
    }
    
    if (isset($_POST['delete_reservation'])) {
        $reservation_id = intval($_POST['reservation_id']);
        $sql = "DELETE FROM reservation WHERE id = $reservation_id";
        
        if (mysqli_query($conn, $sql)) {
            $message = 'Reservation deleted successfully!';
            $message_type = 'success';
        } else {
            $message = 'Error deleting reservation: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['update_status'])) {
        $reservation_id = intval($_POST['reservation_id']);
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        
        $message = 'Reservation status updated!';
        $message_type = 'success';
    }
}

// Get date filter
$date_filter = $_GET['date'] ?? date('Y-m-d');

// Build query - simplified without service join
$query = "
    SELECT r.*, c.full_name as customer_name, c.phone as customer_phone
    FROM reservation r
    JOIN customer c ON r.customer_id = c.id
    WHERE r.reservation_date >= '$date_filter'
    ORDER BY r.reservation_date, r.id DESC
";

$reservations = mysqli_query($conn, $query);

// Fetch customers for dropdown
$customers = mysqli_query($conn, "SELECT * FROM customer ORDER BY full_name");

// Today's reservations
$today_reservations = mysqli_query($conn, "
    SELECT COUNT(*) as count
    FROM reservation
    WHERE DATE(reservation_date) = CURDATE()
");
$today_count = mysqli_fetch_assoc($today_reservations)['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservations - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-calendar-check"></i> Table Reservations</h1>
                <button onclick="document.getElementById('addReservationModal').style.display='block'" 
                        class="btn btn-primary">
                    <i class="fas fa-plus"></i> New Reservation
                </button>
            </div>
            
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <!-- Date Filter -->
            <div class="card">
                <h3>Filter by Date</h3>
                <form method="GET" style="display: flex; gap: 10px; align-items: center;">
                    <input type="date" name="date" value="<?php echo $date_filter; ?>" class="form-control" style="width: 200px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                    <a href="reservations.php" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Today
                    </a>
                </form>
            </div>
            
            <!-- Reservations Table -->
            <div class="card">
                <div class="card-header">
                    <h2>Upcoming Reservations</h2>
                    <span><?php echo mysqli_num_rows($reservations); ?> reservations</span>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Reservation #</th>
                                <th>Customer</th>
                                <th>Date</th>
                                <th>Table</th>
                                <th>Contact</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($reservation = mysqli_fetch_assoc($reservations)): 
                                $status = 'confirmed'; // Default status
                                $status_class = 'status-active';
                                $status_text = 'Confirmed';
                                $today = date('Y-m-d');
                                
                                if ($reservation['reservation_date'] < $today) {
                                    $status_class = 'status-inactive';
                                    $status_text = 'Completed';
                                }
                            ?>
                            <tr>
                                <td>#<?php echo str_pad($reservation['id'], 3, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($reservation['customer_name']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($reservation['reservation_date'])); ?></td>
                                <td>
                                    <?php if (!empty($reservation['table_number'])): ?>
                                    <span class="status-badge status-active">
                                        Table <?php echo htmlspecialchars($reservation['table_number']); ?>
                                    </span>
                                    <?php else: ?>
                                    <span class="status-badge status-inactive">No table</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($reservation['customer_phone']); ?></td>
                                <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span></td>
                                <td>
                                    <button onclick="editReservation(<?php echo $reservation['id']; ?>)" 
                                            class="btn btn-sm btn-primary">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <button onclick="updateStatus(<?php echo $reservation['id']; ?>)" 
                                            class="btn btn-sm btn-success">
                                        <i class="fas fa-cog"></i> Status
                                    </button>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="reservation_id" value="<?php echo $reservation['id']; ?>">
                                        <button type="submit" name="delete_reservation" 
                                                class="btn btn-sm btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this reservation?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($reservations) == 0): ?>
                            <tr>
                                <td colspan="7" style="text-align: center;">No reservations found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="color: #E07B39;">
                        <i class="fas fa-calendar-day"></i>
                    </div>
                    <div class="stat-value"><?php echo $today_count; ?></div>
                    <div class="stat-label">Today's Reservations</div>
                </div>
                
                <?php
                // Total reservations this week
                $week_start = date('Y-m-d', strtotime('monday this week'));
                $week_end = date('Y-m-d', strtotime('sunday this week'));
                $week_reservations = mysqli_query($conn, "
                    SELECT COUNT(*) as count
                    FROM reservation
                    WHERE reservation_date BETWEEN '$week_start' AND '$week_end'
                ");
                $week_count = mysqli_fetch_assoc($week_reservations)['count'];
                
                // Most frequent customer
                $frequent_customer = mysqli_query($conn, "
                    SELECT c.full_name, COUNT(r.id) as count
                    FROM reservation r
                    JOIN customer c ON r.customer_id = c.id
                    GROUP BY c.id
                    ORDER BY count DESC
                    LIMIT 1
                ");
                $frequent = mysqli_fetch_assoc($frequent_customer);
                ?>
                
                <div class="stat-card">
                    <div class="stat-icon" style="color: #9b59b6;">
                        <i class="fas fa-calendar-week"></i>
                    </div>
                    <div class="stat-value"><?php echo $week_count; ?></div>
                    <div class="stat-label">This Week</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="color: #2ecc71;">
                        <i class="fas fa-chair"></i>
                    </div>
                    <div class="stat-value">15</div>
                    <div class="stat-label">Available Tables</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="color: #e74c3c;">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="stat-value"><?php echo $frequent['full_name'] ?? 'N/A'; ?></div>
                    <div class="stat-label">Most Frequent Customer</div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Add Reservation Modal -->
    <div id="addReservationModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
        <div style="background-color: white; margin: 10% auto; padding: 20px; width: 80%; max-width: 500px; border-radius: 5px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>New Table Reservation</h2>
                <span style="cursor: pointer; font-size: 24px;" 
                      onclick="document.getElementById('addReservationModal').style.display='none'">&times;</span>
            </div>
            
            <form method="POST">
                <div class="form-group">
                    <label>Customer *</label>
                    <select name="customer_id" class="form-control" required>
                        <option value="">Select Customer</option>
                        <?php while($customer = mysqli_fetch_assoc($customers)): ?>
                        <option value="<?php echo $customer['id']; ?>">
                            <?php echo htmlspecialchars($customer['full_name']); ?> 
                            (<?php echo htmlspecialchars($customer['phone']); ?>)
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Reservation Date *</label>
                    <input type="date" name="reservation_date" class="form-control" required 
                           min="<?php echo date('Y-m-d'); ?>">
                </div>
                
                <div class="form-group">
                    <label>Table Number (Optional)</label>
                    <input type="text" name="table_number" class="form-control" placeholder="e.g., T1, T2, T3">
                </div>
                
                <div class="form-group">
                    <label>Notes (Optional)</label>
                    <textarea name="notes" class="form-control" rows="3" placeholder="Special requests or notes..."></textarea>
                </div>
                
                <div class="form-group">
                    <button type="submit" name="add_reservation" class="btn btn-primary">
                        <i class="fas fa-calendar-plus"></i> Book Reservation
                    </button>
                    <button type="button" class="btn btn-secondary" 
                            onclick="document.getElementById('addReservationModal').style.display='none'">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Update Status Modal -->
    <div id="statusModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
        <div style="background-color: white; margin: 10% auto; padding: 20px; width: 80%; max-width: 400px; border-radius: 5px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Update Reservation Status</h2>
                <span style="cursor: pointer; font-size: 24px;" 
                      onclick="document.getElementById('statusModal').style.display='none'">&times;</span>
            </div>
            
            <form method="POST" id="statusForm">
                <input type="hidden" name="reservation_id" id="statusReservationId">
                
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control" required>
                        <option value="confirmed">Confirmed</option>
                        <option value="pending">Pending</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <button type="submit" name="update_status" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Status
                    </button>
                    <button type="button" class="btn btn-secondary" 
                            onclick="document.getElementById('statusModal').style.display='none'">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function updateStatus(reservationId) {
        document.getElementById('statusReservationId').value = reservationId;
        document.getElementById('statusModal').style.display = 'block';
    }
    
    function editReservation(reservationId) {
        alert('Edit functionality would be implemented here. Reservation ID: ' + reservationId);
    }
    </script>
</body>
</html>