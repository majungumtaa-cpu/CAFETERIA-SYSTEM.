<?php
// Fix missing created_at column in payment table
require_once 'config.php';

// Check if created_at column exists
$check_column = mysqli_query($conn, "SHOW COLUMNS FROM `payment` LIKE 'created_at'");

if (mysqli_num_rows($check_column) == 0) {
    echo "created_at column not found. Adding it now...\n";
    
    // Try to add the column
    $alter_query = "ALTER TABLE `payment` ADD COLUMN `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP";
    
    if (mysqli_query($conn, $alter_query)) {
        echo "✓ created_at column added successfully!\n";
    } else {
        echo "✗ Error adding column: " . mysqli_error($conn) . "\n";
    }
} else {
    echo "✓ created_at column already exists.\n";
}

// Verify the column was added
$verify = mysqli_query($conn, "SHOW COLUMNS FROM `payment` LIKE 'created_at'");
if (mysqli_num_rows($verify) > 0) {
    echo "✓ Column verified successfully!\n";
} else {
    echo "✗ Column still not found.\n";
}

mysqli_close($conn);
?>
