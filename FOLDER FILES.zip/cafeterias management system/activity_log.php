<?php
// activity_log.php - View audit/activity logs
require_once 'config.php';
check_login();

// Only admins should access this page
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: employee_dashboard.php');
    exit();
}

// Filters
$entity_filter = isset($_GET['entity']) ? mysqli_real_escape_string($conn, $_GET['entity']) : '';
$action_filter = isset($_GET['action']) ? mysqli_real_escape_string($conn, $_GET['action']) : '';
$user_filter = isset($_GET['user']) ? mysqli_real_escape_string($conn, $_GET['user']) : '';
$date_from = isset($_GET['from']) ? mysqli_real_escape_string($conn, $_GET['from']) : '';
$date_to = isset($_GET['to']) ? mysqli_real_escape_string($conn, $_GET['to']) : '';

$where = [];
if ($entity_filter !== '') $where[] = "entity = '$entity_filter'";
if ($action_filter !== '') $where[] = "action = '$action_filter'";
if ($user_filter !== '') $where[] = "username LIKE '%" . mysqli_real_escape_string($conn, $user_filter) . "%'";
if ($date_from !== '') $where[] = "DATE(created_at) >= '$date_from'";
if ($date_to !== '') $where[] = "DATE(created_at) <= '$date_to'";

$where_sql = '';
if (count($where) > 0) $where_sql = 'WHERE ' . implode(' AND ', $where);

$query = "SELECT * FROM activity_log $where_sql ORDER BY created_at DESC LIMIT 500";
$logs = mysqli_query($conn, $query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Activity Log</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    .log-table td, .log-table th { padding: 8px; }
    .log-details { white-space: pre-wrap; font-family: monospace; font-size: 0.9rem; }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container">
        <?php include 'sidebar.php'; ?>
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-clipboard-list"></i> Activity Log</h1>
            </div>

            <!-- Filters removed per request -->

            <div class="card">
                <div class="card-header">
                    <h2>Recent Activity</h2>
                    <span><?php echo mysqli_num_rows($logs); ?> entries</span>
                </div>
                <div class="table-container">
                    <table class="data-table log-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Action</th>
                                <th>Entity</th>
                                <th>Entity ID</th>
                                <th>Details</th>
                                <th>IP</th>
                                <th>When</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($logs)): ?>
                            <tr>
                                <td>#<?php echo str_pad($row['id'], 3, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($row['username'] ?? $row['user_id'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row['action'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row['entity'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars((string)($row['entity_id'] ?? '')); ?></td>
                                <td class="log-details"><?php echo htmlspecialchars($row['details'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row['ip_address'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($row['created_at'] ?? ''); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
