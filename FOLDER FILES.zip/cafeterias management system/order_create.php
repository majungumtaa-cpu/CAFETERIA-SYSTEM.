<?php
// order_create.php
require_once 'config.php';
check_login();

$message = '';
$message_type = '';

// Fetch customers and employees for dropdowns
$customers = mysqli_query($conn, "SELECT * FROM customer ORDER BY full_name");
$employees = mysqli_query($conn, "SELECT * FROM employee ORDER BY full_name");
$products = mysqli_query($conn, "SELECT * FROM product WHERE quantity > 0 ORDER BY product_name");

// Check for query errors
if (!$customers) {
    $message = 'Error loading customers: ' . mysqli_error($conn);
    $message_type = 'error';
}
if (!$employees) {
    $message = 'Error loading employees: ' . mysqli_error($conn);
    $message_type = 'error';
}
if (!$products) {
    $message = 'Error loading products: ' . mysqli_error($conn);
    $message_type = 'error';
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_order'])) {
    $customer_id = intval($_POST['customer_id']);
    $employee_id = intval($_POST['employee_id']);
    
    // Check if employees exist
    $employee_check = mysqli_query($conn, "SELECT COUNT(*) as count FROM employee");
    $employee_count = mysqli_fetch_assoc($employee_check)['count'];
    
    // If no employees exist, allow order creation without employee
    if ($employee_count == 0) {
        $employee_id = null; // Set to null
    } elseif ($employee_id == 0) {
        $message = 'Please select an employee to handle this order.';
        $message_type = 'error';
        goto end;
    }
    
    // Create order
    if ($employee_id === null) {
        $sql = "INSERT INTO `order` (customer_id, order_date) 
                VALUES ($customer_id, NOW())";
    } else {
        $sql = "INSERT INTO `order` (customer_id, employee_id, order_date) 
                VALUES ($customer_id, $employee_id, NOW())";
    }
    
    if (mysqli_query($conn, $sql)) {
        $order_id = mysqli_insert_id($conn);
        
        // Add order items
        if (isset($_POST['product_id']) && is_array($_POST['product_id'])) {
            foreach ($_POST['product_id'] as $index => $product_id) {
                $product_id = intval($product_id);
                $quantity = intval($_POST['quantity'][$index]);
                
                // Skip if product_id is 0 (empty selection) or quantity is 0
                if ($product_id > 0 && $quantity > 0) {
                    // Add to order details
                    $sql = "INSERT INTO order_detail (order_id, product_id, quantity) 
                            VALUES ($order_id, $product_id, $quantity)";
                    
                    if (!mysqli_query($conn, $sql)) {
                        $message = "Error adding item: " . mysqli_error($conn);
                        $message_type = "error";
                        continue;
                    }
                    
                    // Update product quantity
                    $sql = "UPDATE product SET quantity = quantity - $quantity WHERE id = $product_id";
                    mysqli_query($conn, $sql);
                }
            }
        }
        
        $message = "Order #" . $order_id . " created successfully!";
        $message_type = "success";
        if (function_exists('log_activity')) {
            $details = 'customer:' . $customer_id . ';employee:' . ($employee_id !== null ? $employee_id : 'none');
            log_activity($conn, 'add', 'order', $order_id, $details);
        }
        // Redirect to orders list
        header("Location: orders.php?success=Order+created");
        exit();
    } else {
        $message = "Error creating order: " . mysqli_error($conn);
        $message_type = "error";
    }

    end:
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Order - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-plus-circle"></i> Create New Order</h1>
                <a href="orders.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Orders
                </a>
            </div>
            
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <div class="card">
                <form method="POST">
                    <div class="form-group">
                        <label>Customer</label>
                        <select name="customer_id" class="form-control" required>
                            <option value="">Select Customer</option>
                            <?php while($customer = mysqli_fetch_assoc($customers)): ?>
                            <option value="<?php echo $customer['id']; ?>">
                                <?php echo htmlspecialchars($customer['full_name']); ?> 
                                (<?php echo htmlspecialchars($customer['phone']); ?>)
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Employee</label>
                        <select name="employee_id" class="form-control" <?php echo ($employees && mysqli_num_rows($employees) > 0) ? 'required' : ''; ?>>
                            <option value="">Select Employee</option>
                            <?php
                            if ($employees && mysqli_num_rows($employees) > 0) {
                                mysqli_data_seek($employees, 0); // Reset pointer
                                while($employee = mysqli_fetch_assoc($employees)):
                            ?>
                            <option value="<?php echo $employee['id']; ?>">
                                <?php echo htmlspecialchars($employee['full_name']); ?>
                            </option>
                            <?php
                                endwhile;
                            } else {
                                echo '<option value="" disabled>No employees available</option>';
                            }
                            ?>
                        </select>
                        <?php if (!$employees || mysqli_num_rows($employees) == 0): ?>
                        <small class="text-muted">No employees found. Order will be created without employee assignment.</small>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Order Items -->
                    <div class="form-group">
                        <label>Order Items</label>
                        <div id="order-items">
                            <!-- Item rows will be added here -->
                        </div>
                        <button type="button" onclick="addItemRow()" class="btn btn-secondary">
                            <i class="fas fa-plus"></i> Add Item
                        </button>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="create_order" class="btn btn-primary">
                            <i class="fas fa-check"></i> Create Order
                        </button>
                        <a href="orders.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </main>
    </div>
    
    <!-- JavaScript-free way to handle dynamic items -->
    <script type="text/javascript">
    // Simple JavaScript for adding items (kept minimal)
    function addItemRow() {
        var container = document.getElementById('order-items');
        var rowCount = container.children.length;
        
        var row = document.createElement('div');
        row.className = 'item-row';
        row.style.cssText = 'display: flex; gap: 10px; margin-bottom: 10px; align-items: center;';
        
        var productSelect = document.createElement('select');
        productSelect.name = 'product_id[]';
        productSelect.className = 'form-control';
        productSelect.style.flex = '1';
        productSelect.innerHTML = `
            <option value="">Select Product</option>
            <?php 
            // Reset products pointer
            mysqli_data_seek($products, 0);
            while($product = mysqli_fetch_assoc($products)): 
            ?>
            <option value="<?php echo $product['id']; ?>">
                <?php echo htmlspecialchars($product['product_name']); ?> 
                (TZS <?php echo number_format($product['price'], 2); ?>)
            </option>
            <?php endwhile; ?>
        `;
        
        var quantityInput = document.createElement('input');
        quantityInput.type = 'number';
        quantityInput.name = 'quantity[]';
        quantityInput.className = 'form-control';
        quantityInput.min = '1';
        quantityInput.value = '1';
        quantityInput.style.width = '100px';
        
        var removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'btn btn-danger btn-sm';
        removeBtn.innerHTML = '<i class="fas fa-times"></i>';
        removeBtn.onclick = function() {
            container.removeChild(row);
        };
        
        row.appendChild(productSelect);
        row.appendChild(quantityInput);
        row.appendChild(removeBtn);
        container.appendChild(row);
    }
    
    // Add one item row on page load
    document.addEventListener('DOMContentLoaded', function() {
        addItemRow();
    });
    </script>
</body>
</html>