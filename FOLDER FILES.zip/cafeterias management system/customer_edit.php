<?php
// customer_edit.php
require_once 'config.php';
check_login();

$message = '';
$message_type = '';
$customer = null;

// Get customer ID from URL
$customer_id = intval($_GET['id'] ?? 0);

if ($customer_id <= 0) {
    header('Location: customers.php');
    exit;
}

// Fetch customer details
$result = mysqli_query($conn, "SELECT * FROM customer WHERE id = $customer_id");
if (!$result || mysqli_num_rows($result) == 0) {
    header('Location: customers.php');
    exit;
}
$customer = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_customer'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    
    $sql = "UPDATE customer SET full_name = '$full_name', phone = '$phone' WHERE id = $customer_id";
    if (mysqli_query($conn, $sql)) {
        $message = 'Customer updated successfully!';
        $message_type = 'success';
        // Refresh customer data
        $result = mysqli_query($conn, "SELECT * FROM customer WHERE id = $customer_id");
        $customer = mysqli_fetch_assoc($result);
        if (function_exists('log_activity')) {
            $details = 'name:' . ($customer['full_name'] ?? '') . '->' . $full_name . ';phone:' . ($customer['phone'] ?? '') . '->' . $phone;
            log_activity($conn, 'update', 'customer', $customer_id, $details);
        }
    } else {
        $message = 'Error updating customer: ' . mysqli_error($conn);
        $message_type = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Customer - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-edit"></i> Edit Customer</h1>
                <a href="customers.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Customers
                </a>
            </div>
            
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <?php if ($customer): ?>
            <div class="card">
                <div class="card-header">
                    <h2>Edit Customer #<?php echo str_pad($customer['id'], 3, '0', STR_PAD_LEFT); ?></h2>
                </div>
                
                <form method="POST" class="form-container">
                    <div class="form-group">
                        <label>Full Name *</label>
                        <input type="text" name="full_name" class="form-control" 
                               value="<?php echo htmlspecialchars($customer['full_name']); ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" name="phone" class="form-control" 
                               value="<?php echo htmlspecialchars($customer['phone'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="update_customer" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Customer
                        </button>
                        <a href="customers.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
            <?php else: ?>
            <div class="alert alert-error">
                Customer not found.
            </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
