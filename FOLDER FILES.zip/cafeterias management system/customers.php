<?php
// customers.php
require_once 'config.php';
check_login();

// Prevent employees from accessing this page
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: employee_dashboard.php');
    exit();
}

$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_customer'])) {
        $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        
        $sql = "INSERT INTO customer (full_name, phone) VALUES ('$full_name', '$phone')";
        if (mysqli_query($conn, $sql)) {
            $message = 'Customer added successfully!';
            $message_type = 'success';
            if (function_exists('log_activity')) {
                $new_id = mysqli_insert_id($conn);
                $details = 'name:' . $full_name . ';phone:' . $phone;
                log_activity($conn, 'add', 'customer', $new_id, $details);
            }
        } else {
            $message = 'Error adding customer: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['delete_customer'])) {
        $customer_id = intval($_POST['customer_id']);
        
        // Delete related records to avoid foreign key constraint violations
        mysqli_query($conn, "DELETE FROM feedback WHERE customer_id = $customer_id");
        mysqli_query($conn, "DELETE FROM event_customer WHERE customer_id = $customer_id");
        mysqli_query($conn, "DELETE FROM reservation WHERE customer_id = $customer_id");
        
        // Delete orders and associated order details
        $orders = mysqli_query($conn, "SELECT id FROM `order` WHERE customer_id = $customer_id");
        while ($order = mysqli_fetch_assoc($orders)) {
            mysqli_query($conn, "DELETE FROM order_detail WHERE order_id = " . $order['id']);
            mysqli_query($conn, "DELETE FROM payment WHERE order_id = " . $order['id']);
        }
        mysqli_query($conn, "DELETE FROM `order` WHERE customer_id = $customer_id");
        
        // Finally delete the customer
        $sql = "DELETE FROM customer WHERE id = $customer_id";
        if (mysqli_query($conn, $sql)) {
            $message = 'Customer deleted successfully!';
            $message_type = 'success';
            if (function_exists('log_activity')) {
                log_activity($conn, 'delete', 'customer', $customer_id, 'Customer and related records deleted');
            }
        } else {
            $message = 'Error deleting customer: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

// Fetch all customers
$customers = mysqli_query($conn, "SELECT * FROM customer ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-users"></i> Customer Management</h1>
                <button onclick="document.getElementById('addCustomerModal').style.display='block'" 
                        class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add Customer
                </button>
            </div>
            
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2>All Customers</h2>
                    <span><?php echo mysqli_num_rows($customers); ?> customers</span>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Full Name</th>
                                <th>Phone</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($customer = mysqli_fetch_assoc($customers)): ?>
                            <tr>
                                <td>#<?php echo str_pad($customer['id'], 3, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($customer['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($customer['phone']); ?></td>
                                <td>
                                    <a href="customer_edit.php?id=<?php echo $customer['id']; ?>" 
                                       class="btn btn-sm btn-primary">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="customer_id" value="<?php echo $customer['id']; ?>">
                                        <button type="submit" name="delete_customer" 
                                                class="btn btn-sm btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this customer?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($customers) == 0): ?>
                            <tr>
                                <td colspan="4" style="text-align: center;">No customers found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Add Customer Modal -->
    <div id="addCustomerModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
        <div style="background-color: white; margin: 10% auto; padding: 20px; width: 80%; max-width: 500px; border-radius: 5px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Add New Customer</h2>
                <span style="cursor: pointer; font-size: 24px;" 
                      onclick="document.getElementById('addCustomerModal').style.display='none'">&times;</span>
            </div>
            
            <form method="POST">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="tel" name="phone" class="form-control">
                </div>
                
                <div class="form-group">
                    <button type="submit" name="add_customer" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Customer
                    </button>
                    <button type="button" class="btn btn-secondary" 
                            onclick="document.getElementById('addCustomerModal').style.display='none'">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>