<?php
// order_view.php
require_once 'config.php';
check_login();

$order = null;
$order_id = intval($_GET['id'] ?? 0);

if ($order_id <= 0) {
    header('Location: orders.php');
    exit;
}

// Fetch order details
$result = mysqli_query($conn, "
    SELECT o.*, c.full_name as customer_name, c.phone as customer_phone, 
           e.full_name as employee_name, s.service_name
    FROM `order` o
    LEFT JOIN customer c ON o.customer_id = c.id
    LEFT JOIN employee e ON o.employee_id = e.id
    LEFT JOIN service s ON o.service_id = s.id
    WHERE o.id = $order_id
");

if (!$result || mysqli_num_rows($result) == 0) {
    header('Location: orders.php');
    exit;
}

$order = mysqli_fetch_assoc($result);

// Fetch order details (items)
$order_details = mysqli_query($conn, "
    SELECT od.*, p.product_name, p.price
    FROM order_detail od
    JOIN product p ON od.product_id = p.id
    WHERE od.order_id = $order_id
");

// Fetch payment information
$payment = mysqli_query($conn, "
    SELECT p.*, pm.method_name
    FROM payment p
    LEFT JOIN payment_method pm ON p.payment_method_id = pm.id
    WHERE p.order_id = $order_id
");

$payment_info = mysqli_fetch_assoc($payment);

// Calculate total amount
$total_result = mysqli_query($conn, "
    SELECT SUM(od.quantity * p.price) as total
    FROM order_detail od
    JOIN product p ON od.product_id = p.id
    WHERE od.order_id = $order_id
");
$total_row = mysqli_fetch_assoc($total_result);
$total_amount = $total_row['total'] ?? 0;

// Determine status
$status = $payment_info ? 'Paid' : 'Pending';
$status_class = $payment_info ? 'status-active' : 'status-pending';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Order - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-eye"></i> Order Details</h1>
                <a href="orders.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Orders
                </a>
            </div>
            
            <?php if ($order): ?>
            
            <!-- Order Summary -->
            <div class="card">
                <div class="card-header">
                    <h2>Order #<?php echo str_pad($order['id'], 5, '0', STR_PAD_LEFT); ?></h2>
                    <span class="status-badge <?php echo $status_class; ?>"><?php echo $status; ?></span>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; padding: 20px;">
                    <div>
                        <h4>Customer Information</h4>
                        <p><strong>Name:</strong> <?php echo htmlspecialchars($order['customer_name'] ?? 'N/A'); ?></p>
                        <p><strong>Phone:</strong> <?php echo htmlspecialchars($order['customer_phone'] ?? 'N/A'); ?></p>
                    </div>
                    
                    <div>
                        <h4>Employee Information</h4>
                        <p><strong>Name:</strong> <?php echo htmlspecialchars($order['employee_name'] ?? 'N/A'); ?></p>
                    </div>
                    
                    <div>
                        <h4>Order Information</h4>
                        <p><strong>Date:</strong> <?php echo date('M d, Y H:i', strtotime($order['order_date'])); ?></p>
                        <p><strong>Service:</strong> <?php echo htmlspecialchars($order['service_name'] ?? 'N/A'); ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Order Items -->
            <div class="card">
                <div class="card-header">
                    <h2>Order Items</h2>
                </div>
                
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($item = mysqli_fetch_assoc($order_details)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td>TZS <?php echo number_format($item['price'], 2); ?></td>
                                <td>TZS <?php echo number_format($item['quantity'] * $item['price'], 2); ?></td>
                            </tr>
                            <?php endwhile; ?>
                            <tr style="background-color: #f5f5f5; font-weight: bold;">
                                <td colspan="3" style="text-align: right;">Total Amount:</td>
                                <td>TZS <?php echo number_format($total_amount, 2); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Payment Information -->
            <div class="card">
                <div class="card-header">
                    <h2>Payment Information</h2>
                </div>
                
                <?php if ($payment_info): ?>
                <div style="padding: 20px;">
                    <p><strong>Status:</strong> <span class="status-badge status-active">Paid</span></p>
                    <p><strong>Payment Method:</strong> <?php echo htmlspecialchars($payment_info['method_name'] ?? 'N/A'); ?></p>
                    <p><strong>Amount Paid:</strong> TZS <?php echo number_format($payment_info['amount'], 2); ?></p>
                </div>
                <?php else: ?>
                <div style="padding: 20px;">
                    <p><strong>Status:</strong> <span class="status-badge status-pending">Pending</span></p>
                    <p>No payment recorded yet.</p>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Actions -->
            <div class="card">
                <div style="padding: 20px; display: flex; gap: 10px;">
                    <a href="order_edit.php?id=<?php echo $order['id']; ?>" class="btn btn-success">
                        <i class="fas fa-edit"></i> Edit Order
                    </a>
                    <a href="orders.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Orders
                    </a>
                </div>
            </div>
            
            <?php else: ?>
            <div class="alert alert-error">
                Order not found.
            </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
