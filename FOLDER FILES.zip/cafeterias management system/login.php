<?php
// login.php
include 'config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: admin_dashboard.php');
    exit();
}

// Handle login form submission
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Query admin table for authentication
    $query = "SELECT id, username, password, full_name FROM admin WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        // Check password
        if ($admin['password'] === $password) {
            $_SESSION['user_id'] = $admin['id'];
            $_SESSION['username'] = $admin['username'];
            $_SESSION['full_name'] = $admin['full_name'];
            header('Location: admin_dashboard.php');
            exit();
        } else {
            $error = 'Invalid username or password';
        }
    } else {
        $error = 'Invalid username or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            scroll-behavior: smooth;
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, rgba(224, 123, 57, 0) 0%, rgba(200, 106, 47, 0) 100%), url('login.jpg') center/cover no-repeat;
            background-attachment: fixed;
            animation: fadeIn 0.6s ease-in;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .login-box {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
            animation: slideUp 0.8s ease-out;
            transition: all 0.3s ease;
        }

        .login-box:hover {
            box-shadow: 0 20px 45px rgba(0,0,0,0.3);
            transform: translateY(-5px);
        }
        
        .login-logo {
            text-align: center;
            margin-bottom: 30px;
            animation: slideInLeft 0.8s ease-out 0.2s both;
        }
        
        .login-logo h2 {
            color: #E07B39;
            margin-bottom: 10px;
            transition: all 0.3s ease;
        }

        .login-logo h2:hover {
            color: #C86A2F;
            transform: scale(1.05);
        }
        
        .login-footer {
            text-align: center;
            margin-top: 20px;
            color: #7f8c8d;
            font-size: 0.9rem;
            animation: fadeIn 1.2s ease-out 0.6s both;
        }

        .form-group {
            animation: slideInLeft 0.8s ease-out;
            animation-fill-mode: both;
        }

        .form-group:nth-child(1) { animation-delay: 0.3s; }
        .form-group:nth-child(2) { animation-delay: 0.4s; }
        .form-group:nth-child(3) { animation-delay: 0.5s; }

        .form-control {
            transition: all 0.3s ease;
            border: 2px solid #ecf0f1;
        }

        .form-control:focus {
            border-color: #E07B39;
            box-shadow: 0 0 10px rgba(224, 123, 57, 0.2);
            transform: translateX(5px);
        }

        .form-control::placeholder {
            transition: all 0.3s ease;
        }

        .btn {
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 15px rgba(230, 126, 34, 0.3);
        }

        .btn:active {
            transform: translateY(0);
        }

        .alert {
            animation: slideUp 0.5s ease-out;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-box">
            <div class="login-logo">
                <h2><i class="fas fa-utensils"></i> Cafeteria System</h2>
                <p>Please sign in to continue</p>
            </div>
            
            <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" required placeholder="Enter username">
                </div>
                
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" required placeholder="Enter password">
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-sign-in-alt"></i> Sign In
                    </button>
                </div>
            </form>
            
            <div class="login-footer">
                <p>&copy; <?php echo date('Y'); ?> Cafeteria Management System</p>
                <p style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee;">
                    <strong>Employee?</strong> <a href="employee_login.php" style="color: #E07B39; text-decoration: none; font-weight: 600;">Login here</a>
                </p>
            </div>
        </div>
    </div>

    <script>
        // Smooth page load animation
        document.addEventListener('DOMContentLoaded', function() {
            // Add smooth transition to all inputs
            const inputs = document.querySelectorAll('.form-control');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.style.transition = 'all 0.3s ease';
                });
            });

            // Smooth form submission
            const form = document.querySelector('form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    const button = this.querySelector('button[type="submit"]');
                    if (button) {
                        button.style.opacity = '0.7';
                        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Signing in...';
                    }
                });
            }

            // Smooth alert animation
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                alert.style.animation = 'slideUp 0.5s ease-out';
                // Auto-hide alert after 5 seconds
                setTimeout(() => {
                    alert.style.animation = 'slideUp 0.5s ease-out reverse';
                    setTimeout(() => {
                        alert.style.display = 'none';
                    }, 500);
                }, 5000);
            });

            // Smooth navigation on page transitions
            if (window.location.hash) {
                setTimeout(() => {
                    document.querySelector(window.location.hash)?.scrollIntoView({
                        behavior: 'smooth'
                    });
                }, 100);
            }

            // Add keyboard navigation support
            document.addEventListener('keydown', function(e) {
                const inputs = document.querySelectorAll('.form-control');
                if (e.key === 'Tab') {
                    document.activeElement?.classList.add('focus-visible');
                }
            });
        });

        // Prevent multiple form submissions
        let isSubmitting = false;
        document.addEventListener('submit', function(e) {
            const form = e.target;
            if (form.tagName === 'FORM') {
                if (isSubmitting) {
                    e.preventDefault();
                    return false;
                }
                isSubmitting = true;
                setTimeout(() => {
                    isSubmitting = false;
                }, 3000);
            }
        });
    </script>
</body>
</html>