<?php
// reports.php
require_once 'config.php';
check_login();

// Prevent employees from accessing this page
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: employee_dashboard.php');
    exit();
}

// Get report parameters
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');
$report_type = $_GET['type'] ?? 'sales';

// Handle export
if (isset($_GET['export']) && $_GET['export'] == '1') {
    $export_type = $_GET['type'] ?? 'sales';
    
    // Set CSV headers
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $export_type . '_report_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    if ($export_type == 'sales') {
        // Sales Report Export
        fputcsv($output, array('Date', 'Orders', 'Total Sales', 'Average Order'));
        $result = mysqli_query($conn, "
            SELECT DATE(o.order_date) as date, 
                   COUNT(DISTINCT o.id) as order_count,
                   SUM(od.quantity * p.price) as total_sales
            FROM `order` o
            JOIN order_detail od ON o.id = od.order_id
            JOIN product p ON od.product_id = p.id
            WHERE DATE(o.order_date) BETWEEN '$start_date' AND '$end_date'
            GROUP BY DATE(o.order_date)
            ORDER BY date DESC
        ");
        
        while ($row = mysqli_fetch_assoc($result)) {
            $avg_order = $row['order_count'] > 0 ? $row['total_sales'] / $row['order_count'] : 0;
            fputcsv($output, array(
                $row['date'],
                $row['order_count'],
                'TZS ' . number_format($row['total_sales'], 2),
                'TZS ' . number_format($avg_order, 2)
            ));
        }
    } elseif ($export_type == 'products') {
        // Products Report Export
        fputcsv($output, array('Product Name', 'Quantity Sold', 'Total Revenue'));
        $result = mysqli_query($conn, "
            SELECT p.product_name, 
                   SUM(od.quantity) as total_quantity,
                   SUM(od.quantity * p.price) as total_revenue
            FROM order_detail od
            JOIN product p ON od.product_id = p.id
            JOIN `order` o ON od.order_id = o.id
            WHERE DATE(o.order_date) BETWEEN '$start_date' AND '$end_date'
            GROUP BY p.id
            ORDER BY total_revenue DESC
        ");
        
        while ($row = mysqli_fetch_assoc($result)) {
            fputcsv($output, array(
                $row['product_name'],
                $row['total_quantity'],
                'TZS ' . number_format($row['total_revenue'], 2)
            ));
        }
    } elseif ($export_type == 'customers') {
        // Customers Report Export
        fputcsv($output, array('Customer Name', 'Orders', 'Total Spent'));
        $result = mysqli_query($conn, "
            SELECT c.full_name,
                   COUNT(DISTINCT o.id) as order_count,
                   SUM(od.quantity * p.price) as total_spent
            FROM customer c
            JOIN `order` o ON c.id = o.customer_id
            JOIN order_detail od ON o.id = od.order_id
            JOIN product p ON od.product_id = p.id
            WHERE DATE(o.order_date) BETWEEN '$start_date' AND '$end_date'
            GROUP BY c.id
            ORDER BY total_spent DESC
        ");
        
        while ($row = mysqli_fetch_assoc($result)) {
            fputcsv($output, array(
                $row['full_name'],
                $row['order_count'],
                'TZS ' . number_format($row['total_spent'], 2)
            ));
        }
    } elseif ($export_type == 'stock') {
        // Stock Status Export
        fputcsv($output, array('Product Name', 'Category', 'Quantity', 'Status'));
        $result = mysqli_query($conn, "
            SELECT p.product_name, mc.category_name, p.quantity,
                   CASE WHEN p.quantity >= 20 THEN 'In Stock'
                        WHEN p.quantity > 0 THEN 'Low Stock'
                        ELSE 'Out of Stock' END as status
            FROM product p
            LEFT JOIN menu_category mc ON p.category_id = mc.id
            ORDER BY p.product_name
        ");

        while ($row = mysqli_fetch_assoc($result)) {
            fputcsv($output, array(
                $row['product_name'],
                $row['category_name'],
                $row['quantity'],
                $row['status']
            ));
        }
    }
    
    fclose($output);
    exit;
}

// Generate sales report
$sales_report = mysqli_query($conn, "
    SELECT DATE(o.order_date) as date, 
           COUNT(DISTINCT o.id) as order_count,
           SUM(od.quantity * p.price) as total_sales
    FROM `order` o
    JOIN order_detail od ON o.id = od.order_id
    JOIN product p ON od.product_id = p.id
    WHERE DATE(o.order_date) BETWEEN '$start_date' AND '$end_date'
    GROUP BY DATE(o.order_date)
    ORDER BY date DESC
");

// Top products
$top_products = mysqli_query($conn, "
    SELECT p.product_name, 
           SUM(od.quantity) as total_quantity,
           SUM(od.quantity * p.price) as total_revenue
    FROM order_detail od
    JOIN product p ON od.product_id = p.id
    JOIN `order` o ON od.order_id = o.id
    WHERE DATE(o.order_date) BETWEEN '$start_date' AND '$end_date'
    GROUP BY p.id
    ORDER BY total_revenue DESC
    LIMIT 10
");

// Top customers
$top_customers = mysqli_query($conn, "
    SELECT c.full_name,
           COUNT(DISTINCT o.id) as order_count,
           SUM(od.quantity * p.price) as total_spent
    FROM customer c
    JOIN `order` o ON c.id = o.customer_id
    JOIN order_detail od ON o.id = od.order_id
    JOIN product p ON od.product_id = p.id
    WHERE DATE(o.order_date) BETWEEN '$start_date' AND '$end_date'
    GROUP BY c.id
    ORDER BY total_spent DESC
    LIMIT 10
");

// Stock status (inventory) for reports
$stock_status = mysqli_query($conn, "
    SELECT p.id, p.product_name, mc.category_name, p.quantity,
           CASE WHEN p.quantity >= 20 THEN 'In Stock'
                WHEN p.quantity > 0 THEN 'Low Stock'
                ELSE 'Out of Stock' END as status
    FROM product p
    LEFT JOIN menu_category mc ON p.category_id = mc.id
    ORDER BY p.quantity ASC
");

// Summary statistics
$summary = mysqli_query($conn, "
    SELECT 
        COUNT(DISTINCT o.id) as total_orders,
        COUNT(DISTINCT c.id) as total_customers,
        SUM(od.quantity * p.price) as total_revenue,
        AVG(od.quantity * p.price) as avg_order_value
    FROM `order` o
    JOIN customer c ON o.customer_id = c.id
    JOIN order_detail od ON o.id = od.order_id
    JOIN product p ON od.product_id = p.id
    WHERE DATE(o.order_date) BETWEEN '$start_date' AND '$end_date'
");

$summary_data = mysqli_fetch_assoc($summary);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-chart-bar"></i> Reports & Analytics</h1>
                <form method="GET" style="display: flex; gap: 10px;">
                    <input type="date" name="start_date" value="<?php echo $start_date; ?>" class="form-control">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Generate
                    </button>
                </form>
            </div>
            
            <!-- Stock Status Report -->
            <div class="card" style="margin-top: 20px;">
                <div class="card-header">
                    <h2>Stock Status Report</h2>
                    <span><?php echo mysqli_num_rows($stock_status); ?> items</span>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Category</th>
                                <th>Quantity</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($item = mysqli_fetch_assoc($stock_status)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td><?php echo htmlspecialchars($item['category_name']); ?></td>
                                <td><?php echo intval($item['quantity']); ?></td>
                                <td>
                                    <?php
                                    $cls = '';
                                    if ($item['quantity'] >= 20) $cls = 'status-active';
                                    elseif ($item['quantity'] > 0) $cls = 'status-pending';
                                    else $cls = 'status-inactive';
                                    ?>
                                    <span class="status-badge <?php echo $cls; ?>"><?php echo $item['status']; ?></span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($stock_status) == 0): ?>
                            <tr>
                                <td colspan="4" style="text-align: center;">No inventory data available</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Summary Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="color: #E07B39;">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stat-value"><?php echo $summary_data['total_orders'] ?? 0; ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="color: #2ecc71;">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-value">TZS <?php echo number_format($summary_data['total_revenue'] ?? 0, 2); ?></div>
                    <div class="stat-label">Total Revenue</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="color: #9b59b6;">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-value"><?php echo $summary_data['total_customers'] ?? 0; ?></div>
                    <div class="stat-label">Active Customers</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="color: #f39c12;">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="stat-value">TZS <?php echo number_format($summary_data['avg_order_value'] ?? 0, 2); ?></div>
                    <div class="stat-label">Avg Order Value</div>
                </div>
            </div>
            
            <!-- Sales Report -->
            <div class="card">
                <div class="card-header">
                    <h2>Daily Sales Report</h2>
                    <span><?php echo date('M d, Y', strtotime($start_date)); ?> to <?php echo date('M d, Y', strtotime($end_date)); ?></span>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Orders</th>
                                <th>Total Sales</th>
                                <th>Average Order</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($sales_report)): 
                                $avg_order = $row['order_count'] > 0 ? $row['total_sales'] / $row['order_count'] : 0;
                            ?>
                            <tr>
                                <td><?php echo date('M d, Y', strtotime($row['date'])); ?></td>
                                <td><?php echo $row['order_count']; ?></td>
                                <td>$<?php echo number_format($row['total_sales'], 2); ?></td>
                                <td>$<?php echo number_format($avg_order, 2); ?></td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($sales_report) == 0): ?>
                            <tr>
                                <td colspan="4" style="text-align: center;">No sales data for selected period</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Top Products and Customers -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
                <!-- Top Products -->
                <div class="card">
                    <div class="card-header">
                        <h2>Top Products</h2>
                    </div>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity Sold</th>
                                    <th>Revenue</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($product = mysqli_fetch_assoc($top_products)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                    <td><?php echo $product['total_quantity']; ?></td>
                                    <td>$<?php echo number_format($product['total_revenue'], 2); ?></td>
                                </tr>
                                <?php endwhile; ?>
                                <?php if(mysqli_num_rows($top_products) == 0): ?>
                                <tr>
                                    <td colspan="3" style="text-align: center;">No product data</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Top Customers -->
                <div class="card">
                    <div class="card-header">
                        <h2>Top Customers</h2>
                    </div>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Orders</th>
                                    <th>Total Spent</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($customer = mysqli_fetch_assoc($top_customers)): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($customer['full_name']); ?></td>
                                    <td><?php echo $customer['order_count']; ?></td>
                                    <td>$<?php echo number_format($customer['total_spent'], 2); ?></td>
                                </tr>
                                <?php endwhile; ?>
                                <?php if(mysqli_num_rows($top_customers) == 0): ?>
                                <tr>
                                    <td colspan="3" style="text-align: center;">No customer data</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Export Options -->
            <div class="card">
                <div class="card-header">
                    <h2>Export Reports</h2>
                </div>
                <div style="padding: 20px;">
                    <form method="GET" target="_blank">
                        <input type="hidden" name="start_date" value="<?php echo $start_date; ?>">
                        <input type="hidden" name="end_date" value="<?php echo $end_date; ?>">
                        <input type="hidden" name="export" value="1">
                        
                        <div style="display: flex; gap: 10px;">
                            <button type="submit" name="type" value="sales" class="btn btn-primary">
                                <i class="fas fa-file-csv"></i> Export Sales Report
                            </button>
                            <button type="submit" name="type" value="products" class="btn btn-success">
                                <i class="fas fa-file-csv"></i> Export Products Report
                            </button>
                            <button type="submit" name="type" value="customers" class="btn btn-secondary">
                                <i class="fas fa-file-csv"></i> Export Customers Report
                            </button>
                            <button type="submit" name="type" value="stock" class="btn btn-warning">
                                <i class="fas fa-file-csv"></i> Export Stock Report
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
</body>
</html>