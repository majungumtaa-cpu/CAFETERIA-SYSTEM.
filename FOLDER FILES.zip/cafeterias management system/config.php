<?php
// config.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database configuration (can be overridden with environment variables)
// Examples (replace YOUR_DB_PASSWORD with the real password):
// ASP.NET connection string:
// Server=MYSQL8003.site4now.net;Database=db_ac5859_cafeter;Uid=ac5859_cafeter;Pwd=YOUR_DB_PASSWORD
// PHP ODBC connection string (ODBC driver):
// Driver={MySQL ODBC 8.0 UNICODE Driver};Server=MYSQL8003.site4now.net;Database=db_ac5859_cafeter;Uid=ac5859_cafeter;Password=YOUR_DB_PASSWORD

// You can export environment variables to override these values instead of editing this file:
// DB_HOST, DB_USER, DB_PASS, DB_NAME
$host = getenv('DB_HOST') ?: 'localhost';
$username = getenv('DB_USER') ?: 'root';
$password = getenv('DB_PASS') ?: '';
$database = getenv('DB_NAME') ?: 'cafeterias';

// Create connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set charset
mysqli_set_charset($conn, "utf8mb4");

// Ensure activity_log table exists (create if missing)
$create_activity_table_sql = "CREATE TABLE IF NOT EXISTS activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    username VARCHAR(255) NULL,
    action VARCHAR(32) NOT NULL,
    entity VARCHAR(100) NOT NULL,
    entity_id INT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
mysqli_query($conn, $create_activity_table_sql);

// Set DB session vars for activity logging (so triggers can pick up user info)
$user_id_val = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;
$username_val = null;
if (isset($_SESSION['username'])) $username_val = $_SESSION['username'];
elseif (isset($_SESSION['full_name'])) $username_val = $_SESSION['full_name'];
$ip_val = $_SERVER['REMOTE_ADDR'] ?? null;
$set_sql = "SET @current_user_id = " . ($user_id_val !== null ? $user_id_val : 'NULL') . ", @current_username = " . ($username_val !== null ? "'" . mysqli_real_escape_string($conn, $username_val) . "'" : 'NULL') . ", @current_user_ip = " . ($ip_val !== null ? "'" . mysqli_real_escape_string($conn, $ip_val) . "'" : 'NULL') . ";";
@mysqli_query($conn, $set_sql);

// Create DB triggers for key tables if missing (product, customer)
$db = mysqli_real_escape_string($conn, '') ?: '';
$check = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() AND TRIGGER_NAME = 'tr_product_insert'");
$row = mysqli_fetch_assoc($check);
if (!$row || $row['cnt'] == 0) {
    @mysqli_query($conn, "CREATE TRIGGER tr_product_insert AFTER INSERT ON product FOR EACH ROW INSERT INTO activity_log (user_id, username, action, entity, entity_id, details, ip_address) VALUES (@current_user_id, @current_username, 'add', 'product', NEW.id, CONCAT('name:',NEW.product_name,';price:',NEW.price,';quantity:',NEW.quantity), @current_user_ip)");
}
$check = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() AND TRIGGER_NAME = 'tr_product_update'");
$row = mysqli_fetch_assoc($check);
if (!$row || $row['cnt'] == 0) {
    @mysqli_query($conn, "CREATE TRIGGER tr_product_update AFTER UPDATE ON product FOR EACH ROW INSERT INTO activity_log (user_id, username, action, entity, entity_id, details, ip_address) VALUES (@current_user_id, @current_username, 'update', 'product', NEW.id, CONCAT('old_qty:',OLD.quantity,'->new_qty:',NEW.quantity,';name:',NEW.product_name), @current_user_ip)");
}
$check = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() AND TRIGGER_NAME = 'tr_product_delete'");
$row = mysqli_fetch_assoc($check);
if (!$row || $row['cnt'] == 0) {
    @mysqli_query($conn, "CREATE TRIGGER tr_product_delete AFTER DELETE ON product FOR EACH ROW INSERT INTO activity_log (user_id, username, action, entity, entity_id, details, ip_address) VALUES (@current_user_id, @current_username, 'delete', 'product', OLD.id, CONCAT('name:',OLD.product_name,';quantity:',OLD.quantity), @current_user_ip)");
}

$check = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() AND TRIGGER_NAME = 'tr_customer_insert'");
$row = mysqli_fetch_assoc($check);
if (!$row || $row['cnt'] == 0) {
    @mysqli_query($conn, "CREATE TRIGGER tr_customer_insert AFTER INSERT ON customer FOR EACH ROW INSERT INTO activity_log (user_id, username, action, entity, entity_id, details, ip_address) VALUES (@current_user_id, @current_username, 'add', 'customer', NEW.id, CONCAT('name:',NEW.full_name,';phone:',NEW.phone), @current_user_ip)");
}
$check = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() AND TRIGGER_NAME = 'tr_customer_update'");
$row = mysqli_fetch_assoc($check);
if (!$row || $row['cnt'] == 0) {
    @mysqli_query($conn, "CREATE TRIGGER tr_customer_update AFTER UPDATE ON customer FOR EACH ROW INSERT INTO activity_log (user_id, username, action, entity, entity_id, details, ip_address) VALUES (@current_user_id, @current_username, 'update', 'customer', NEW.id, CONCAT('old_phone:',OLD.phone,'->new_phone:',NEW.phone,';name:',NEW.full_name), @current_user_ip)");
}
$check = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA = DATABASE() AND TRIGGER_NAME = 'tr_customer_delete'");
$row = mysqli_fetch_assoc($check);
if (!$row || $row['cnt'] == 0) {
    @mysqli_query($conn, "CREATE TRIGGER tr_customer_delete AFTER DELETE ON customer FOR EACH ROW INSERT INTO activity_log (user_id, username, action, entity, entity_id, details, ip_address) VALUES (@current_user_id, @current_username, 'delete', 'customer', OLD.id, CONCAT('name:',OLD.full_name,';phone:',OLD.phone), @current_user_ip)");
}

// Check if user is logged in (for protected pages)
function check_login() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit();
    }
}

// Simple authentication
function authenticate($username, $password) {
    global $conn;
    
    // For demo purposes - in production, use prepared statements and password hashing
    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['user_id'] = 1;
        $_SESSION['username'] = 'admin';
        $_SESSION['full_name'] = 'Administrator';
        return true;
    }
    return false;
}

// Audit / Activity logging helper
function log_activity($conn, $action, $entity, $entity_id = null, $details = null) {
    $user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;
    $username = isset($_SESSION['username']) ? $_SESSION['username'] : (isset($_SESSION['full_name']) ? $_SESSION['full_name'] : null);
    $ip = $_SERVER['REMOTE_ADDR'] ?? null;

    $user_val = $user_id !== null ? intval($user_id) : 'NULL';
    $username_val = $username !== null ? "'" . mysqli_real_escape_string($conn, $username) . "'" : 'NULL';
    $action_val = "'" . mysqli_real_escape_string($conn, $action) . "'";
    $entity_val = "'" . mysqli_real_escape_string($conn, $entity) . "'";
    $entity_id_val = $entity_id !== null ? intval($entity_id) : 'NULL';
    $details_val = $details !== null ? "'" . mysqli_real_escape_string($conn, $details) . "'" : 'NULL';
    $ip_val = $ip !== null ? "'" . mysqli_real_escape_string($conn, $ip) . "'" : 'NULL';

    $sql = "INSERT INTO activity_log (user_id, username, action, entity, entity_id, details, ip_address) VALUES ($user_val, $username_val, $action_val, $entity_val, $entity_id_val, $details_val, $ip_val)";
    @mysqli_query($conn, $sql);
}
?>