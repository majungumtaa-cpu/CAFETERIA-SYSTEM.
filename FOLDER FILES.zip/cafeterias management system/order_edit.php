<?php
// order_edit.php
require_once 'config.php';
check_login();

$message = '';
$message_type = '';
$order = null;

// Get order ID from URL
$order_id = intval($_GET['id'] ?? 0);

if ($order_id <= 0) {
    header('Location: orders.php');
    exit;
}

// Fetch order details
$result = mysqli_query($conn, "
    SELECT o.*, c.full_name as customer_name, e.full_name as employee_name
    FROM `order` o
    LEFT JOIN customer c ON o.customer_id = c.id
    LEFT JOIN employee e ON o.employee_id = e.id
    WHERE o.id = $order_id
");

if (!$result || mysqli_num_rows($result) == 0) {
    header('Location: orders.php');
    exit;
}

$order = mysqli_fetch_assoc($result);

// Fetch customers for dropdown
$customers = mysqli_query($conn, "SELECT id, full_name FROM customer ORDER BY full_name");

// Fetch employees for dropdown
$employees = mysqli_query($conn, "SELECT id, full_name FROM employee ORDER BY full_name");

// Fetch services for dropdown
$services = mysqli_query($conn, "SELECT id, service_name FROM service ORDER BY service_name");

// Fetch order items
$order_details = mysqli_query($conn, "
    SELECT od.*, p.product_name, p.price
    FROM order_detail od
    JOIN product p ON od.product_id = p.id
    WHERE od.order_id = $order_id
");

// Fetch all products for dropdown
$all_products = mysqli_query($conn, "SELECT id, product_name, price FROM product ORDER BY product_name");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_order'])) {
    $customer_id = intval($_POST['customer_id'] ?? 0);
    $employee_id = intval($_POST['employee_id'] ?? 0);
    $service_id = intval($_POST['service_id'] ?? 0) ?: null;
    
    // Validate inputs
    if ($customer_id <= 0) {
        $message = 'Please select a customer!';
        $message_type = 'error';
    } elseif ($employee_id <= 0) {
        $message = 'Please select an employee!';
        $message_type = 'error';
    } else {
        $service_id_sql = $service_id ? $service_id : 'NULL';
        $sql = "UPDATE `order` SET customer_id = $customer_id, employee_id = $employee_id, 
                service_id = $service_id_sql WHERE id = $order_id";
        if (mysqli_query($conn, $sql)) {
            $message = 'Order updated successfully!';
            $message_type = 'success';
            // Refresh order data
            $result = mysqli_query($conn, "
                SELECT o.*, c.full_name as customer_name, e.full_name as employee_name
                FROM `order` o
                LEFT JOIN customer c ON o.customer_id = c.id
                LEFT JOIN employee e ON o.employee_id = e.id
                WHERE o.id = $order_id
            ");
            $order = mysqli_fetch_assoc($result);
        } else {
            $message = 'Error updating order: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

// Handle adding order items
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_item'])) {
    $product_id = intval($_POST['product_id'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 0);
    
    if ($product_id <= 0) {
        $message = 'Please select a product!';
        $message_type = 'error';
    } elseif ($quantity <= 0) {
        $message = 'Quantity must be greater than 0!';
        $message_type = 'error';
    } else {
        // Check if product already exists in order
        $check = mysqli_query($conn, "SELECT id FROM order_detail WHERE order_id = $order_id AND product_id = $product_id");
        if (mysqli_num_rows($check) > 0) {
            // Update quantity
            $update_sql = "UPDATE order_detail SET quantity = quantity + $quantity WHERE order_id = $order_id AND product_id = $product_id";
            mysqli_query($conn, $update_sql);
        } else {
            // Add new item
            $insert_sql = "INSERT INTO order_detail (order_id, product_id, quantity) VALUES ($order_id, $product_id, $quantity)";
            mysqli_query($conn, $insert_sql);
        }
        $message = 'Item added successfully!';
        $message_type = 'success';
    }
}

// Handle removing order items
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['remove_item'])) {
    $detail_id = intval($_POST['detail_id'] ?? 0);
    $sql = "DELETE FROM order_detail WHERE id = $detail_id AND order_id = $order_id";
    if (mysqli_query($conn, $sql)) {
        $message = 'Item removed successfully!';
        $message_type = 'success';
    } else {
        $message = 'Error removing item: ' . mysqli_error($conn);
        $message_type = 'error';
    }
}

// Recalculate total amount
$total_result = mysqli_query($conn, "
    SELECT SUM(od.quantity * p.price) as total
    FROM order_detail od
    JOIN product p ON od.product_id = p.id
    WHERE od.order_id = $order_id
");
$total_row = mysqli_fetch_assoc($total_result);
$total_amount = $total_row['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-edit"></i> Edit Order</h1>
                <a href="orders.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Orders
                </a>
            </div>
            
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <?php if ($order): ?>
            
            <!-- Order Information -->
            <div class="card">
                <div class="card-header">
                    <h2>Order #<?php echo str_pad($order['id'], 5, '0', STR_PAD_LEFT); ?></h2>
                </div>
                
                <form method="POST" class="form-container">
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label>Customer *</label>
                            <select name="customer_id" class="form-control" required>
                                <option value="">Select Customer</option>
                                <?php 
                                // Reset pointer and fetch again
                                mysqli_data_seek($customers, 0);
                                while ($cust = mysqli_fetch_assoc($customers)): 
                                ?>
                                <option value="<?php echo $cust['id']; ?>" 
                                    <?php echo $cust['id'] == $order['customer_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cust['full_name']); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Employee *</label>
                            <select name="employee_id" class="form-control" required>
                                <option value="">Select Employee</option>
                                <?php 
                                // Reset pointer and fetch again
                                mysqli_data_seek($employees, 0);
                                while ($emp = mysqli_fetch_assoc($employees)): 
                                ?>
                                <option value="<?php echo $emp['id']; ?>" 
                                    <?php echo $emp['id'] == $order['employee_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($emp['full_name']); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Service</label>
                            <select name="service_id" class="form-control">
                                <option value="">No Service</option>
                                <?php 
                                // Reset pointer and fetch again
                                mysqli_data_seek($services, 0);
                                while ($svc = mysqli_fetch_assoc($services)): 
                                ?>
                                <option value="<?php echo $svc['id']; ?>" 
                                    <?php echo $svc['id'] == $order['service_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($svc['service_name']); ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="update_order" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Order
                        </button>
                        <a href="orders.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
            
            <!-- Order Items -->
            <div class="card">
                <div class="card-header">
                    <h2>Order Items</h2>
                </div>
                
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Subtotal</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            mysqli_data_seek($order_details, 0);
                            while ($item = mysqli_fetch_assoc($order_details)): 
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td>TZS <?php echo number_format($item['price'], 2); ?></td>
                                <td>TZS <?php echo number_format($item['quantity'] * $item['price'], 2); ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="detail_id" value="<?php echo $item['id']; ?>">
                                        <button type="submit" name="remove_item" class="btn btn-sm btn-danger" 
                                                onclick="return confirm('Are you sure?');">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <tr style="background-color: #f5f5f5; font-weight: bold;">
                                <td colspan="3" style="text-align: right;">Total Amount:</td>
                                <td>TZS <?php echo number_format($total_amount, 2); ?></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Add Item -->
            <div class="card">
                <div class="card-header">
                    <h2>Add Item to Order</h2>
                </div>
                
                <form method="POST" class="form-container">
                    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label>Product *</label>
                            <select name="product_id" class="form-control" required>
                                <option value="">Select Product</option>
                                <?php 
                                mysqli_data_seek($all_products, 0);
                                while ($prod = mysqli_fetch_assoc($all_products)): 
                                ?>
                                <option value="<?php echo $prod['id']; ?>">
                                    <?php echo htmlspecialchars($prod['product_name']); ?> 
                                    (TZS <?php echo number_format($prod['price'], 2); ?>)
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Quantity *</label>
                            <input type="number" name="quantity" class="form-control" 
                                   value="1" min="1" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="add_item" class="btn btn-success">
                            <i class="fas fa-plus"></i> Add Item
                        </button>
                    </div>
                </form>
            </div>
            
            <?php else: ?>
            <div class="alert alert-error">
                Order not found.
            </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
