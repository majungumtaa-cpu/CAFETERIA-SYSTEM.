<?php
// payments.php
require_once 'config.php';
check_login();

// Prevent employees from accessing this page
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: employee_dashboard.php');
    exit();
}

$message = '';
$message_type = '';

// Handle payment processing
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['process_payment'])) {
        $order_id = intval($_POST['order_id']);
        $payment_method_id = intval($_POST['payment_method_id']);
        $amount = floatval($_POST['amount']);
        
        // Validate payment doesn't exceed order total
        $order_total = 0;
        $result = mysqli_query($conn, "
            SELECT SUM(od.quantity * p.price) as total
            FROM order_detail od
            JOIN product p ON od.product_id = p.id
            WHERE od.order_id = $order_id
        ");
        if ($row = mysqli_fetch_assoc($result)) {
            $order_total = $row['total'];
        }
        
        if ($amount <= $order_total) {
            $sql = "INSERT INTO payment (order_id, payment_method_id, amount) 
                    VALUES ($order_id, $payment_method_id, $amount)";
            
            if (mysqli_query($conn, $sql)) {
                $payment_id = mysqli_insert_id($conn);
                $message = 'Payment processed successfully!';
                $message_type = 'success';
                if (function_exists('log_activity')) {
                    $details = 'order:' . $order_id . ';method_id:' . $payment_method_id . ';amount:' . number_format($amount,2);
                    log_activity($conn, 'add', 'payment', $payment_id, $details);
                }
            } else {
                $message = 'Error processing payment: ' . mysqli_error($conn);
                $message_type = 'error';
            }
        } else {
            $message = 'Payment amount exceeds order total!';
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['delete_payment'])) {
        $payment_id = intval($_POST['payment_id']);
        $sql = "DELETE FROM payment WHERE id = $payment_id";
        
        if (mysqli_query($conn, $sql)) {
            $message = 'Payment deleted successfully!';
            $message_type = 'success';
            if (function_exists('log_activity')) {
                log_activity($conn, 'delete', 'payment', $payment_id, 'Payment record deleted');
            }
        } else {
            $message = 'Error deleting payment: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

// Fetch all payments with details
$payments = mysqli_query($conn, "
    SELECT p.*, o.id as order_number, pm.method_name, c.full_name as customer_name, 
           o.order_date, p.amount as payment_amount
    FROM payment p
    JOIN `order` o ON p.order_id = o.id
    JOIN payment_method pm ON p.payment_method_id = pm.id
    JOIN customer c ON o.customer_id = c.id
    ORDER BY p.id DESC
");

// Fetch payment methods for dropdown
$payment_methods = mysqli_query($conn, "SELECT * FROM payment_method");

// Check if payment methods table is empty and populate with defaults
if (mysqli_num_rows($payment_methods) == 0) {
    // Insert default payment methods
    $default_methods = ['Cash', 'Credit Card', 'Debit Card', 'Mobile Money', 'Bank Transfer'];
    foreach ($default_methods as $method) {
        mysqli_query($conn, "INSERT IGNORE INTO payment_method (method_name) VALUES ('$method')");
    }
    // Re-fetch payment methods
    $payment_methods = mysqli_query($conn, "SELECT * FROM payment_method");
}

// Fetch pending orders (orders without payment)
$pending_orders = mysqli_query($conn, "
    SELECT o.*, c.full_name as customer_name,
           COALESCE((SELECT SUM(od.quantity * pr.price) 
            FROM order_detail od 
            JOIN product pr ON od.product_id = pr.id 
            WHERE od.order_id = o.id), 0) as order_total
    FROM `order` o
    JOIN customer c ON o.customer_id = c.id
    WHERE NOT EXISTS (
        SELECT 1 FROM payment p WHERE p.order_id = o.id
    )
    ORDER BY o.order_date DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-credit-card"></i> Payment Management</h1>
                <button onclick="document.getElementById('addPaymentModal').style.display='block'" 
                        class="btn btn-primary">
                    <i class="fas fa-plus"></i> Process Payment
                </button>
            </div>
            
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <!-- Pending Orders -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-clock"></i> Pending Payments</h2>
                    <span><?php echo mysqli_num_rows($pending_orders); ?> pending orders</span>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Order Date</th>
                                <th>Total Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($order = mysqli_fetch_assoc($pending_orders)): ?>
                            <tr>
                                <td>#<?php echo str_pad($order['id'], 5, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                                <td>TZS <?php echo number_format($order['order_total'] ?? 0, 2); ?></td>
                                <td>
                                    <button onclick="processOrderPayment(<?php echo $order['id']; ?>, <?php echo $order['order_total']; ?>, '<?php echo htmlspecialchars($order['customer_name']); ?>')" 
                                            class="btn btn-sm btn-success">
                                        <i class="fas fa-money-bill-wave"></i> Pay Now
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($pending_orders) == 0): ?>
                            <tr>
                                <td colspan="5" style="text-align: center;">All orders are paid</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Payment History -->
            <div class="card">
                <div class="card-header">
                    <h2>Payment History</h2>
                    <span><?php echo mysqli_num_rows($payments); ?> payments</span>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Payment #</th>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Payment Method</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($payment = mysqli_fetch_assoc($payments)): ?>
                            <tr>
                                <td>#<?php echo str_pad($payment['id'], 3, '0', STR_PAD_LEFT); ?></td>
                                <td>#<?php echo str_pad($payment['order_id'], 5, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($payment['customer_name']); ?></td>
                                <td><?php echo htmlspecialchars($payment['method_name']); ?></td>
                                <td>TZS <?php echo number_format($payment['amount'] ?? 0, 2); ?></td>
                                <td><?php echo date('M d, Y', strtotime($payment['order_date'])); ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="payment_id" value="<?php echo $payment['id']; ?>">
                                        <button type="submit" name="delete_payment" 
                                                class="btn btn-sm btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this payment?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($payments) == 0): ?>
                            <tr>
                                <td colspan="7" style="text-align: center;">No payments found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Payment Statistics -->
            <div class="stats-grid">
                <?php
                // Today's payments
                $today = date('Y-m-d');
                $today_payments = mysqli_query($conn, "
                    SELECT SUM(amount) as total
                    FROM payment
                    WHERE DATE(created_at) = '$today' OR 1=1
                ");
                $today_total = mysqli_fetch_assoc($today_payments)['total'] ?? 0;
                
                // This month payments
                $month_start = date('Y-m-01');
                $month_end = date('Y-m-t');
                $month_payments = mysqli_query($conn, "
                    SELECT SUM(amount) as total
                    FROM payment
                    WHERE DATE(created_at) BETWEEN '$month_start' AND '$month_end'
                ");
                $month_total = mysqli_fetch_assoc($month_payments)['total'] ?? 0;
                
                // Payment methods distribution
                $method_distribution = mysqli_query($conn, "
                    SELECT pm.method_name, COUNT(p.id) as count, SUM(p.amount) as total
                    FROM payment p
                    JOIN payment_method pm ON p.payment_method_id = pm.id
                    GROUP BY pm.id
                    ORDER BY total DESC
                ");
                ?>
                
                <div class="stat-card">
                    <div class="stat-icon" style="color: #2ecc71;">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-value">TZS <?php echo number_format($today_total ?? 0, 2); ?></div>
                    <div class="stat-label">Today's Payments</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="color: #E07B39;">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div class="stat-value">TZS <?php echo number_format($month_total ?? 0, 2); ?></div>
                    <div class="stat-label">This Month</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon" style="color: #9b59b6;">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <div class="stat-value"><?php echo mysqli_num_rows($payment_methods); ?></div>
                    <div class="stat-label">Payment Methods</div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Add Payment Modal -->
    <div id="addPaymentModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
        <div style="background-color: white; margin: 10% auto; padding: 20px; width: 80%; max-width: 500px; border-radius: 5px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Process New Payment</h2>
                <span style="cursor: pointer; font-size: 24px;" 
                      onclick="document.getElementById('addPaymentModal').style.display='none'">&times;</span>
            </div>
            
            <form method="POST" id="paymentForm">
                <div class="form-group">
                    <label>Order</label>
                    <select name="order_id" id="orderSelect" class="form-control" required>
                        <option value="">Select Order</option>
                        <?php 
                        // Reset pointer
                        mysqli_data_seek($pending_orders, 0);
                        while($order = mysqli_fetch_assoc($pending_orders)): 
                        ?>
                        <option value="<?php echo $order['id']; ?>" data-total="<?php echo $order['order_total']; ?>">
                            Order #<?php echo str_pad($order['id'], 5, '0', STR_PAD_LEFT); ?> - 
                            <?php echo htmlspecialchars($order['customer_name']); ?> - 
                            $<?php echo number_format($order['order_total'] ?? 0, 2); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Payment Method</label>
                    <select name="payment_method_id" class="form-control" required>
                        <option value="">Select Method</option>
                        <?php 
                        mysqli_data_seek($payment_methods, 0);
                        while($method = mysqli_fetch_assoc($payment_methods)): 
                        ?>
                        <option value="<?php echo $method['id']; ?>">
                            <?php echo htmlspecialchars($method['method_name']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Amount ($)</label>
                    <input type="number" name="amount" id="paymentAmount" class="form-control" step="0.01" min="0.01" required>
                    <small id="orderTotalInfo" style="color: #666; display: none;">Order total: $<span id="totalAmount">0.00</span></small>
                </div>
                
                <div class="form-group">
                    <button type="submit" name="process_payment" class="btn btn-primary">
                        <i class="fas fa-check"></i> Process Payment
                    </button>
                    <button type="button" class="btn btn-secondary" 
                            onclick="document.getElementById('addPaymentModal').style.display='none'">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function processOrderPayment(orderId, orderTotal, customerName) {
        document.getElementById('addPaymentModal').style.display = 'block';
        document.getElementById('orderSelect').value = orderId;
        document.getElementById('paymentAmount').value = orderTotal;
        document.getElementById('totalAmount').textContent = orderTotal.toFixed(2);
        document.getElementById('orderTotalInfo').style.display = 'block';
        
        // Trigger change event to update display
        var event = new Event('change');
        document.getElementById('orderSelect').dispatchEvent(event);
    }
    
    // Update amount when order is selected
    document.getElementById('orderSelect').addEventListener('change', function() {
        var selectedOption = this.options[this.selectedIndex];
        var orderTotal = selectedOption.getAttribute('data-total');
        if (orderTotal) {
            document.getElementById('paymentAmount').value = orderTotal;
            document.getElementById('totalAmount').textContent = orderTotal;
            document.getElementById('orderTotalInfo').style.display = 'block';
        } else {
            document.getElementById('orderTotalInfo').style.display = 'none';
        }
    });
    </script>
</body>
</html>