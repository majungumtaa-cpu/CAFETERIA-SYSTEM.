<?php
// index.php (Landing Page)
session_start();

// If user is already logged in, redirect to appropriate dashboard
if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
        header('Location: employee_dashboard.php');
        exit();
    } else {
        header('Location: admin_dashboard.php');
        exit();
    }
}

// If admin login requested, show unified staff login
if (isset($_GET['admin'])) {
    header('Location: staff_login.php');
    exit();
}

// If customer portal requested, redirect to customer login
if (isset($_GET['customer'])) {
    header('Location: user/');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cafeteria Management System</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, rgba(224, 123, 57, 0) 0%, rgba(200, 106, 47, 0) 100%), url('index.jpg') center/cover no-repeat;
            background-attachment: fixed;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow-x: hidden;
        }

        .landing-container {
            text-align: center;
            color: white;
            max-width: 1200px;
            padding: 60px 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 25px;
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
        }

        .landing-container::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
            100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
        }

        .logo {
            font-size: 5em;
            margin-bottom: 30px;
            text-shadow: 0 2px 6px rgba(0, 0, 0, 0.5), 0 4px 12px rgba(0, 0, 0, 0.3);
            animation: pulse 2s ease-in-out infinite;
            display: inline-block;
            color: #FFFFFF;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        h1 {
            font-size: 3.5em;
            margin-bottom: 15px;
            color: #FFFFFF;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5), 0 4px 8px rgba(0, 0, 0, 0.4);
            font-weight: 700;
            letter-spacing: -1px;
        }

        .tagline {
            font-size: 1.4em;
            margin-bottom: 50px;
            opacity: 1;
            color: #FFFFFF;
            font-weight: 300;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.4;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
        }

        .portal-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 40px;
            margin-top: 50px;
        }

        .portal-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            padding: 40px 30px;
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            cursor: pointer;
            text-decoration: none;
            color: white;
            display: block;
            position: relative;
            overflow: hidden;
        }

        .portal-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .portal-card:hover::before {
            left: 100%;
        }

        .portal-card:hover {
            transform: translateY(-15px) scale(1.02);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.3);
            background: rgba(255, 255, 255, 0.25);
        }

        .portal-icon {
            font-size: 4em;
            margin-bottom: 25px;
            display: block;
            text-shadow: 0 2px 6px rgba(0, 0, 0, 0.4), 0 4px 12px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease;
            color: #FFFFFF;
        }

        .portal-card:hover .portal-icon {
            transform: scale(1.1) rotate(5deg);
        }

        .portal-title {
            font-size: 1.8em;
            font-weight: 700;
            margin-bottom: 15px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
            color: #FFFFFF;
        }

        .portal-description {
            font-size: 1.1em;
            opacity: 1;
            line-height: 1.6;
            font-weight: 300;
            color: #FFFFFF;
            text-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
        }

        .features-section {
            margin-top: 80px;
            padding: 40px 0;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }

        .feature-item {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 25px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .feature-item:hover {
            transform: translateY(-5px);
        }

        .feature-icon {
            font-size: 2.5em;
            margin-bottom: 15px;
            display: block;
            text-shadow: 0 0 15px rgba(255, 255, 255, 0.5);
        }

        .feature-title {
            font-size: 1.3em;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .feature-description {
            font-size: 0.95em;
            opacity: 0.8;
            line-height: 1.5;
        }

        @media (max-width: 768px) {
            .landing-container {
                margin: 20px;
                padding: 40px 25px;
            }

            h1 {
                font-size: 2.8em;
            }

            .tagline {
                font-size: 1.2em;
            }

            .portal-grid {
                grid-template-columns: 1fr;
                gap: 25px;
            }

            .features-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .admin-link {
                position: relative;
                top: auto;
                right: auto;
                margin-top: 20px;
                display: inline-block;
            }
        }
    </style>
</head>
<body>
    <div class="landing-container">
        <div class="logo">
            <i class="fas fa-utensils"></i>
        </div>

        <h1>Welcome to Our Cafeteria</h1>
        <p class="tagline">Delicious food, great service, unforgettable experiences</p>

        <div class="portal-grid">
            <a href="user/" class="portal-card">
                <i class="fas fa-store portal-icon"></i>
                <div class="portal-title">Customer Portal</div>
                <div class="portal-description">
                    Browse our menu, place orders, and register for events.
                    Experience our cafeteria from the comfort of your device.
                </div>
            </a>

            <a href="?admin=1" class="portal-card">
                <i class="fas fa-user-shield portal-icon"></i>
                <div class="portal-title">Staff Portal</div>
                <div class="portal-description">
                    Access the management system to handle orders, manage inventory,
                    process payments, and oversee daily operations.
                </div>
            </a>
        </div>

        <div class="features-section">
            <h2 style="font-size: 2.2em; margin-bottom: 15px; text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);">Why Choose Our Cafeteria?</h2>
            <p style="font-size: 1.1em; opacity: 0.8; margin-bottom: 40px;">Experience excellence in every aspect of our service</p>

            <div class="features-grid">
                <div class="feature-item">
                    <i class="fas fa-utensils feature-icon"></i>
                    <div class="feature-title">Fresh & Quality Food</div>
                    <div class="feature-description">We serve only the freshest ingredients with authentic flavors that satisfy your cravings.</div>
                </div>

                <div class="feature-item">
                    <i class="fas fa-clock feature-icon"></i>
                    <div class="feature-title">Quick Service</div>
                    <div class="feature-description">Fast and efficient service ensures you get your food hot and fresh without long waits.</div>
                </div>

                <div class="feature-item">
                    <i class="fas fa-calendar-alt feature-icon"></i>
                    <div class="feature-title">Event Catering</div>
                    <div class="feature-description">Perfect for your special occasions with customizable menus and professional service.</div>
                </div>

                <div class="feature-item">
                    <i class="fas fa-wifi feature-icon"></i>
                    <div class="feature-title">Modern Experience</div>
                    <div class="feature-description">Order online, make reservations, and enjoy a seamless digital experience.</div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>