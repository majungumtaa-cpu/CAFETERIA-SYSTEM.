<?php
// orders.php
require_once 'config.php';
check_login();

// Prevent employees from accessing this page
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: employee_dashboard.php');
    exit();
}

// Handle order deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_order'])) {
    $order_id = intval($_POST['order_id']);
    
    // Delete order details first
    mysqli_query($conn, "DELETE FROM order_detail WHERE order_id = $order_id");
    
    // Delete associated payments
    mysqli_query($conn, "DELETE FROM payment WHERE order_id = $order_id");
    
    // Delete the order
    $sql = "DELETE FROM `order` WHERE id = $order_id";
    if (mysqli_query($conn, $sql)) {
        $message = 'Order deleted successfully!';
        $message_type = 'success';
        if (function_exists('log_activity')) {
            log_activity($conn, 'delete', 'order', $order_id, 'Order and related records deleted');
        }
    } else {
        $message = 'Error deleting order: ' . mysqli_error($conn);
        $message_type = 'error';
    }
}

// Handle order status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    
    // First check if status column exists
    $check_column = mysqli_query($conn, "SHOW COLUMNS FROM `order` LIKE 'status'");
    
    if (mysqli_num_rows($check_column) > 0) {
        // Column exists, update it
        $valid_statuses = ['pending', 'processing', 'completed', 'cancelled'];
        if (in_array($status, $valid_statuses)) {
            // fetch old status for logging
            $old_status = null;
            $res_old = mysqli_query($conn, "SELECT status FROM `order` WHERE id = $order_id LIMIT 1");
            if ($res_old && mysqli_num_rows($res_old) > 0) {
                $old_status = mysqli_fetch_assoc($res_old)['status'];
            }
            $sql = "UPDATE `order` SET status = '$status' WHERE id = $order_id";
            if (mysqli_query($conn, $sql)) {
                $message = "Order #" . $order_id . " status updated to: " . ucfirst($status);
                $message_type = "success";
                if (function_exists('log_activity')) {
                    $details = 'status:' . ($old_status ?? 'unknown') . '->' . $status;
                    log_activity($conn, 'update', 'order', $order_id, $details);
                }
            } else {
                $message = "Error updating order status: " . mysqli_error($conn);
                $message_type = "error";
            }
        } else {
            $message = "Invalid status value!";
            $message_type = "error";
        }
    } else {
        // Column doesn't exist, show error with instructions
        $message = "Error: Status column not found in database. Please run this SQL command in phpMyAdmin: ALTER TABLE `order` ADD COLUMN `status` VARCHAR(50) DEFAULT 'pending' AFTER `order_date`;";
        $message_type = "error";
    }
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : '';
$date_filter = isset($_GET['date']) ? mysqli_real_escape_string($conn, $_GET['date']) : '';

// Build query
$query = "
    SELECT o.*, c.full_name as customer_name, e.full_name as employee_name,
           s.service_name, 
           (SELECT SUM(od.quantity * p.price) 
            FROM order_detail od 
            JOIN product p ON od.product_id = p.id 
            WHERE od.order_id = o.id) as total_amount
    FROM `order` o
    LEFT JOIN customer c ON o.customer_id = c.id
    LEFT JOIN employee e ON o.employee_id = e.id
    LEFT JOIN service s ON o.service_id = s.id
    WHERE 1=1
";

// Apply status filter
if ($status_filter && $status_filter !== '') {
    // If the `status` column exists on `order`, prefer using it
    $check_column = mysqli_query($conn, "SHOW COLUMNS FROM `order` LIKE 'status'");
    if (mysqli_num_rows($check_column) > 0) {
        $safe_status = mysqli_real_escape_string($conn, $status_filter);
        $query .= " AND o.status = '$safe_status'";
    } else {
        // Fallback to payment-based heuristic when status column is not present
        if ($status_filter === 'completed') {
            $query .= " AND EXISTS (SELECT 1 FROM payment WHERE payment.order_id = o.id)";
        } elseif ($status_filter === 'pending') {
            $query .= " AND NOT EXISTS (SELECT 1 FROM payment WHERE payment.order_id = o.id)";
        } elseif ($status_filter === 'processing') {
            // Processing orders are treated like pending if no explicit status
            $query .= " AND NOT EXISTS (SELECT 1 FROM payment WHERE payment.order_id = o.id)";
        } elseif ($status_filter === 'cancelled') {
            // No cancellation system: return none when requested
            $query .= " AND 1=0";
        }
    }
}

// Apply date filter
if ($date_filter && $date_filter !== '') {
    $query .= " AND DATE(o.order_date) = '$date_filter'";
}

$query .= " ORDER BY o.order_date DESC";

$orders = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-shopping-cart"></i> Order Management</h1>
                <a href="order_create.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Create Order
                </a>
            </div>
            
            <?php if (isset($message)): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <!-- Filters -->
            <div class="card">
                <h3>Filters</h3>
                <form method="GET" action="orders.php" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: flex-end;">
                    <div>
                        <label for="status_filter">Status:</label>
                        <select name="status" id="status_filter" class="form-control" style="width: 150px;">
                            <option value="">All Status</option>
                            <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="processing" <?php echo $status_filter == 'processing' ? 'selected' : ''; ?>>Processing</option>
                            <option value="completed" <?php echo $status_filter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="cancelled" <?php echo $status_filter == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    
                    <div>
                        <label for="date_filter">Date:</label>
                        <input type="date" name="date" id="date_filter" value="<?php echo htmlspecialchars($date_filter); ?>" class="form-control" style="width: 150px;">
                    </div>
                    
                    <div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-filter"></i> Filter
                        </button>
                        <a href="orders.php" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Clear
                        </a>
                    </div>
                </form>
            </div>
            
            <!-- Orders Table -->
            <div class="card">
                <div class="card-header">
                    <h2>All Orders</h2>
                    <span><?php echo mysqli_num_rows($orders); ?> orders found</span>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Order #</th>
                                <th>Customer</th>
                                <th>Employee</th>
                                <th>Service</th>
                                <th>Date</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($order = mysqli_fetch_assoc($orders)): 
                                // Get status from database or fallback to checking payments
                                $status = isset($order['status']) ? $order['status'] : 'pending';
                                
                                // If status column doesn't exist, check payment status as fallback
                                if (empty($status) || !isset($order['status'])) {
                                    $has_payment = mysqli_query($conn, "SELECT id FROM payment WHERE order_id = " . $order['id']);
                                    $status = mysqli_num_rows($has_payment) > 0 ? 'completed' : 'pending';
                                }
                                
                                // Map status to display class and text
                                $status_map = [
                                    'pending' => ['status-pending', 'Pending'],
                                    'processing' => ['status-pending', 'Processing'],
                                    'completed' => ['status-active', 'Completed'],
                                    'cancelled' => ['status-danger', 'Cancelled']
                                ];
                                $status_class = $status_map[$status][0] ?? 'status-pending';
                                $status_text = $status_map[$status][1] ?? 'Unknown';
                            ?>
                            <tr>
                                <td>#<?php echo str_pad($order['id'], 5, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                <td><?php echo htmlspecialchars($order['employee_name']); ?></td>
                                <td><?php echo htmlspecialchars($order['service_name'] ?? 'N/A'); ?></td>
                                <td><?php echo date('M d, Y H:i', strtotime($order['order_date'])); ?></td>
                                <td>TZS <?php echo number_format($order['total_amount'] ?? 0, 2); ?></td>
                                <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span></td>
                                <td>
                                    <a href="order_view.php?id=<?php echo $order['id']; ?>" 
                                       class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    <a href="order_edit.php?id=<?php echo $order['id']; ?>" 
                                       class="btn btn-sm btn-success">
                                        <i class="fas fa-edit"></i> Edit
                                    </a>
                                    <button onclick="document.getElementById('statusModal<?php echo $order['id']; ?>').style.display='block'"
                                            class="btn btn-sm btn-secondary">
                                        <i class="fas fa-cog"></i> Status
                                    </button>
                                    <?php if ($status == 'completed'): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                        <button type="submit" name="delete_order" class="btn btn-sm btn-danger" 
                                                onclick="return confirm('Are you sure you want to delete this completed order?');">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            
                            <!-- Status Update Modal -->
                            <div id="statusModal<?php echo $order['id']; ?>" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
                                <div style="background-color: white; margin: 10% auto; padding: 20px; width: 80%; max-width: 400px; border-radius: 5px;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                                        <h3>Update Order Status</h3>
                                        <span style="cursor: pointer; font-size: 24px;" 
                                              onclick="document.getElementById('statusModal<?php echo $order['id']; ?>').style.display='none'">&times;</span>
                                    </div>
                                    
                                    <form method="POST">
                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                        
                                        <div class="form-group">
                                            <label>Status</label>
                                            <select name="status" class="form-control" required>
                                                <option value="pending">Pending</option>
                                                <option value="processing">Processing</option>
                                                <option value="completed">Completed</option>
                                                <option value="cancelled">Cancelled</option>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <button type="submit" name="update_status" class="btn btn-primary">
                                                <i class="fas fa-save"></i> Update Status
                                            </button>
                                            <button type="button" class="btn btn-secondary" 
                                                    onclick="document.getElementById('statusModal<?php echo $order['id']; ?>').style.display='none'">
                                                Cancel
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($orders) == 0): ?>
                            <tr>
                                <td colspan="8" style="text-align: center;">No orders found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div style="display: flex; justify-content: center; margin-top: 20px;">
                    <div class="pagination">
                        <a href="?page=1">&laquo;</a>
                        <a href="?page=1">1</a>
                        <a href="?page=2">2</a>
                        <a href="?page=3">3</a>
                        <span class="current">Page 1</span>
                        <a href="?page=2">&raquo;</a>
                    </div>
                </div>
            </div>
            
            <!-- Order Summary -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-chart-line"></i> Order Summary</h2>
                </div>
                <div class="stats-grid">
                    <?php
                    // Today's orders
                    $today_orders = mysqli_query($conn, "
                        SELECT COUNT(*) as count 
                        FROM `order` 
                        WHERE DATE(order_date) = CURDATE()
                    ");
                    $row = mysqli_fetch_assoc($today_orders);
                    $today_count = $row['count'];
                    
                    // Today's revenue
                    $today_revenue = mysqli_query($conn, "
                        SELECT SUM(od.quantity * p.price) as revenue
                        FROM `order` o
                        JOIN order_detail od ON o.id = od.order_id
                        JOIN product p ON od.product_id = p.id
                        WHERE DATE(o.order_date) = CURDATE()
                    ");
                    $row = mysqli_fetch_assoc($today_revenue);
                    $today_revenue_amount = $row['revenue'] ?? 0;
                    
                    // Pending orders
                    $pending_orders = mysqli_query($conn, "
                        SELECT COUNT(DISTINCT o.id) as count
                        FROM `order` o
                        LEFT JOIN payment p ON o.id = p.order_id
                        WHERE p.id IS NULL
                    ");
                    $row = mysqli_fetch_assoc($pending_orders);
                    $pending_count = $row['count'];
                    
                    // Average order value
                    $avg_order = mysqli_query($conn, "
                        SELECT AVG(sub.total) as avg_value
                        FROM (
                            SELECT SUM(od.quantity * p.price) as total
                            FROM `order` o
                            JOIN order_detail od ON o.id = od.order_id
                            JOIN product p ON od.product_id = p.id
                            GROUP BY o.id
                        ) as sub
                    ");
                    $row = mysqli_fetch_assoc($avg_order);
                    $avg_order_value = $row['avg_value'] ?? 0;
                    ?>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="color: #E07B39;">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="stat-value"><?php echo $today_count; ?></div>
                        <div class="stat-label">Today's Orders</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="color: #2ecc71;">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                        <div class="stat-value">TZS <?php echo number_format($today_revenue_amount, 2); ?></div>
                        <div class="stat-label">Today's Revenue</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="color: #f39c12;">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="stat-value"><?php echo $pending_count; ?></div>
                        <div class="stat-label">Pending Payments</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="color: #9b59b6;">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <div class="stat-value">TZS <?php echo number_format($avg_order_value, 2); ?></div>
                        <div class="stat-label">Avg Order Value</div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>