<?php
// suppliers.php - Fixed version
require_once 'config.php';
check_login();

// Prevent employees from accessing this page
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: employee_dashboard.php');
    exit();
}

$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_supplier'])) {
        $supplier_name = mysqli_real_escape_string($conn, $_POST['supplier_name']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        
        $sql = "INSERT INTO supplier (supplier_name, phone) 
                VALUES ('$supplier_name', '$phone')";
        
        if (mysqli_query($conn, $sql)) {
            $supplier_id = mysqli_insert_id($conn);
            $message = 'Supplier added successfully!';
            $message_type = 'success';
            if (function_exists('log_activity')) {
                $details = 'name:' . $supplier_name . ';phone:' . $phone;
                log_activity($conn, 'add', 'supplier', $supplier_id, $details);
            }
        } else {
            $message = 'Error adding supplier: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['delete_supplier'])) {
        $supplier_id = intval($_POST['supplier_id']);
        
        // Delete related purchase records first
        mysqli_query($conn, "DELETE FROM purchase WHERE supplier_id = $supplier_id");
        
        // Then delete the supplier
        $sql = "DELETE FROM supplier WHERE id = $supplier_id";
        
        if (mysqli_query($conn, $sql)) {
            $message = 'Supplier deleted successfully!';
            $message_type = 'success';
            if (function_exists('log_activity')) {
                log_activity($conn, 'delete', 'supplier', $supplier_id, 'Supplier and purchase records deleted');
            }
        } else {
            $message = 'Error deleting supplier: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
    
    if (isset($_POST['add_purchase'])) {
        $supplier_id = intval($_POST['purchase_supplier_id']);
        $product_id = intval($_POST['product_id']);
        $quantity = intval($_POST['quantity']);
        
        // Add purchase record
        $sql = "INSERT INTO purchase (supplier_id, product_id, quantity) 
                VALUES ($supplier_id, $product_id, $quantity)";
        
        if (mysqli_query($conn, $sql)) {
            // Update product stock
            $update_sql = "UPDATE product SET quantity = quantity + $quantity WHERE id = $product_id";
            mysqli_query($conn, $update_sql);
            
            $purchase_id = mysqli_insert_id($conn);
            $message = 'Purchase order created successfully!';
            $message_type = 'success';
            if (function_exists('log_activity')) {
                $details = 'supplier:' . $supplier_id . ';product:' . $product_id . ';qty:' . $quantity;
                log_activity($conn, 'add', 'purchase', $purchase_id, $details);
            }
        } else {
            $message = 'Error creating purchase order: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

// Fetch all suppliers
$suppliers = mysqli_query($conn, "SELECT * FROM supplier ORDER BY supplier_name");

// Fetch products for purchase dropdown
$products = mysqli_query($conn, "SELECT * FROM product ORDER BY product_name");

// Fetch recent purchases
$purchases = mysqli_query($conn, "
    SELECT pu.*, s.supplier_name, p.product_name
    FROM purchase pu
    JOIN supplier s ON pu.supplier_id = s.id
    JOIN product p ON pu.product_id = p.id
    ORDER BY pu.id DESC
    LIMIT 10
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suppliers - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-truck"></i> Supplier Management</h1>
                <div style="display: flex; gap: 10px;">
                    <button onclick="document.getElementById('addPurchaseModal').style.display='block'" 
                            class="btn btn-success">
                        <i class="fas fa-shopping-cart"></i> New Purchase
                    </button>
                    <button onclick="document.getElementById('addSupplierModal').style.display='block'" 
                            class="btn btn-primary">
                        <i class="fas fa-plus"></i> Add Supplier
                    </button>
                </div>
            </div>
            
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <!-- Suppliers List -->
            <div class="card">
                <div class="card-header">
                    <h2>All Suppliers</h2>
                    <span><?php echo mysqli_num_rows($suppliers); ?> suppliers</span>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Supplier Name</th>
                                <th>Contact</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($supplier = mysqli_fetch_assoc($suppliers)): ?>
                            <tr>
                                <td>#<?php echo str_pad($supplier['id'], 3, '0', STR_PAD_LEFT); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($supplier['supplier_name']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($supplier['phone']); ?></td>
                                <td>
                                    <button onclick="viewSupplier(<?php echo $supplier['id']; ?>)" 
                                            class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                    <button onclick="editSupplier(<?php echo $supplier['id']; ?>)" 
                                            class="btn btn-sm btn-success">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="supplier_id" value="<?php echo $supplier['id']; ?>">
                                        <button type="submit" name="delete_supplier" 
                                                class="btn btn-sm btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this supplier?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($suppliers) == 0): ?>
                            <tr>
                                <td colspan="4" style="text-align: center;">No suppliers found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Recent Purchases -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-history"></i> Recent Purchases</h2>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Purchase #</th>
                                <th>Supplier</th>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($purchase = mysqli_fetch_assoc($purchases)): ?>
                            <tr>
                                <td>#<?php echo str_pad($purchase['id'], 3, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($purchase['supplier_name']); ?></td>
                                <td><?php echo htmlspecialchars($purchase['product_name']); ?></td>
                                <td><?php echo $purchase['quantity']; ?></td>
                                <td><?php echo date('M d, Y'); ?></td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($purchases) == 0): ?>
                            <tr>
                                <td colspan="5" style="text-align: center;">No purchases found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Add Supplier Modal -->
    <div id="addSupplierModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
        <div style="background-color: white; margin: 5% auto; padding: 20px; width: 80%; max-width: 500px; border-radius: 5px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Add New Supplier</h2>
                <span style="cursor: pointer; font-size: 24px;" 
                      onclick="document.getElementById('addSupplierModal').style.display='none'">&times;</span>
            </div>
            
            <form method="POST">
                <div class="form-group">
                    <label>Supplier Name *</label>
                    <input type="text" name="supplier_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Phone Number *</label>
                    <input type="tel" name="phone" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <button type="submit" name="add_supplier" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Supplier
                    </button>
                    <button type="button" class="btn btn-secondary" 
                            onclick="document.getElementById('addSupplierModal').style.display='none'">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Add Purchase Modal -->
    <div id="addPurchaseModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
        <div style="background-color: white; margin: 5% auto; padding: 20px; width: 80%; max-width: 500px; border-radius: 5px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Create Purchase Order</h2>
                <span style="cursor: pointer; font-size: 24px;" 
                      onclick="document.getElementById('addPurchaseModal').style.display='none'">&times;</span>
            </div>
            
            <form method="POST">
                <div class="form-group">
                    <label>Supplier *</label>
                    <select name="purchase_supplier_id" class="form-control" required>
                        <option value="">Select Supplier</option>
                        <?php 
                        mysqli_data_seek($suppliers, 0);
                        while($supplier = mysqli_fetch_assoc($suppliers)): 
                        ?>
                        <option value="<?php echo $supplier['id']; ?>">
                            <?php echo htmlspecialchars($supplier['supplier_name']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Product *</label>
                    <select name="product_id" class="form-control" required>
                        <option value="">Select Product</option>
                        <?php 
                        mysqli_data_seek($products, 0);
                        while($product = mysqli_fetch_assoc($products)): 
                        ?>
                        <option value="<?php echo $product['id']; ?>">
                            <?php echo htmlspecialchars($product['product_name']); ?> 
                            (Current Stock: <?php echo $product['quantity']; ?>)
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Quantity *</label>
                    <input type="number" name="quantity" class="form-control" min="1" required value="1">
                </div>
                
                <div class="form-group">
                    <button type="submit" name="add_purchase" class="btn btn-primary">
                        <i class="fas fa-shopping-cart"></i> Create Purchase Order
                    </button>
                    <button type="button" class="btn btn-secondary" 
                            onclick="document.getElementById('addPurchaseModal').style.display='none'">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function viewSupplier(supplierId) {
        alert('View supplier details for ID: ' + supplierId);
    }
    
    function editSupplier(supplierId) {
        alert('Edit supplier with ID: ' + supplierId);
    }
    </script>
</body>
</html>