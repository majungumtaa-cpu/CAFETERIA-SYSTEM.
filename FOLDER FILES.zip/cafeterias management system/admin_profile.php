<?php
// admin_profile.php
require_once 'config.php';
check_login();

// Prevent employees from accessing this page
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: employee_dashboard.php');
    exit();
}

$message = '';
$message_type = '';
$admin_id = $_SESSION['user_id'];

// Fetch current admin details
$admin_query = mysqli_query($conn, "SELECT * FROM admin WHERE id = $admin_id");
$admin = mysqli_fetch_assoc($admin_query);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $full_name = mysqli_real_escape_string($conn, $_POST['full_name'] ?? '');
        $username = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
        
        if (empty($full_name)) {
            $message = 'Full name cannot be empty!';
            $message_type = 'error';
        } elseif (empty($username)) {
            $message = 'Username cannot be empty!';
            $message_type = 'error';
        } else {
            // Check if username is already taken by another admin
            $check_username = mysqli_query($conn, "SELECT id FROM admin WHERE username = '$username' AND id != $admin_id");
            if (mysqli_num_rows($check_username) > 0) {
                $message = 'Username is already taken!';
                $message_type = 'error';
            } else {
                // Update admin profile
                $update_query = "UPDATE admin SET full_name = '$full_name', username = '$username' WHERE id = $admin_id";
                if (mysqli_query($conn, $update_query)) {
                    $_SESSION['full_name'] = $full_name;
                    $_SESSION['username'] = $username;
                    $message = 'Profile updated successfully!';
                    $message_type = 'success';
                    // Refresh admin data
                    $admin_query = mysqli_query($conn, "SELECT * FROM admin WHERE id = $admin_id");
                    $admin = mysqli_fetch_assoc($admin_query);
                    if (function_exists('log_activity')) {
                        $details = 'full_name:' . ($admin['full_name'] ?? '') . '->' . $full_name . ';username:' . ($admin['username'] ?? '') . '->' . $username;
                        log_activity($conn, 'update', 'admin', $admin_id, $details);
                    }
                } else {
                    $message = 'Error updating profile: ' . mysqli_error($conn);
                    $message_type = 'error';
                }
            }
        }
    }
    
    // Handle password change
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        // Verify current password
        if ($current_password !== $admin['password']) {
            $message = 'Current password is incorrect!';
            $message_type = 'error';
        } elseif (empty($new_password)) {
            $message = 'New password cannot be empty!';
            $message_type = 'error';
        } elseif (strlen($new_password) < 4) {
            $message = 'Password must be at least 4 characters long!';
            $message_type = 'error';
        } elseif ($new_password !== $confirm_password) {
            $message = 'Passwords do not match!';
            $message_type = 'error';
        } else {
            // Update password in database
            $new_password_safe = mysqli_real_escape_string($conn, $new_password);
            $update_password = "UPDATE admin SET password = '$new_password_safe' WHERE id = $admin_id";
            if (mysqli_query($conn, $update_password)) {
                $admin['password'] = $new_password;
                $message = 'Password changed successfully!';
                $message_type = 'success';
                if (function_exists('log_activity')) {
                    log_activity($conn, 'update', 'admin', $admin_id, 'password changed');
                }
            } else {
                $message = 'Error changing password: ' . mysqli_error($conn);
                $message_type = 'error';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .profile-container {
            max-width: 800px;
            margin: 0 auto;
        }

        .profile-card {
            background: white;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .profile-header {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
        }

        .profile-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2rem;
        }

        .profile-info h2 {
            margin: 0 0 5px 0;
            color: #333;
        }

        .profile-info p {
            margin: 0;
            color: #999;
            font-size: 0.9rem;
        }

        .form-section {
            margin-bottom: 30px;
        }

        .form-section h3 {
            color: #333;
            font-size: 1.1rem;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            font-size: 0.95rem;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #ecf0f1;
            border-radius: 6px;
            font-size: 0.95rem;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            outline: none;
            border-color: #E07B39;
        }

        .alert {
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .btn-group {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #E07B39;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }

        .back-link:hover {
            color: #C86A2F;
        }

        .divider {
            height: 1px;
            background: #f0f0f0;
            margin: 30px 0;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="profile-container">
                <a href="admin_dashboard.php" class="back-link">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>

                <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo $message; ?>
                </div>
                <?php endif; ?>

                <!-- Profile Information Card -->
                <div class="profile-card">
                    <div class="profile-header">
                        <div class="profile-avatar">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <div class="profile-info">
                            <h2><?php echo htmlspecialchars($_SESSION['full_name']); ?></h2>
                            <p>Administrator Account</p>
                        </div>
                    </div>

                    <!-- Update Profile Section -->
                    <div class="form-section">
                        <h3><i class="fas fa-user"></i> Update Profile</h3>
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="full_name">Full Name</label>
                                <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($admin['full_name']); ?>" required>
                            </div>
                            <div class="btn-group">
                                <button type="submit" name="update_profile" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update Profile
                                </button>
                            </div>
                        </form>
                    </div>

                    <div class="divider"></div>

                    <!-- Change Password Section -->
                    <div class="form-section">
                        <h3><i class="fas fa-lock"></i> Change Password</h3>
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" id="current_password" name="current_password" required>
                            </div>
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password" required>
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password</label>
                                <input type="password" id="confirm_password" name="confirm_password" required>
                            </div>
                            <div class="btn-group">
                                <button type="submit" name="change_password" class="btn btn-primary">
                                    <i class="fas fa-key"></i> Change Password
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
