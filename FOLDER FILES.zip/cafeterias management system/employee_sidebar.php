<?php
// employee_sidebar.php
?>
<aside class="sidebar">
    <nav class="sidebar-nav">
        <li>
            <a href="employee_dashboard.php" <?php echo (basename($_SERVER['PHP_SELF']) === 'employee_dashboard.php') ? 'class="active"' : ''; ?>>
                <i class="fas fa-home"></i> Dashboard
            </a>
        </li>
        <li>
            <a href="employee_shifts.php" <?php echo (basename($_SERVER['PHP_SELF']) === 'employee_shifts.php') ? 'class="active"' : ''; ?>>
                <i class="fas fa-clock"></i> My Shifts
            </a>
        </li>
        <li>
            <a href="employee_orders.php" <?php echo (basename($_SERVER['PHP_SELF']) === 'employee_orders.php') ? 'class="active"' : ''; ?>>
                <i class="fas fa-shopping-cart"></i> My Orders
            </a>
        </li>
        <li>
            <a href="employee_products.php" <?php echo (basename($_SERVER['PHP_SELF']) === 'employee_products.php') ? 'class="active"' : ''; ?>>
                <i class="fas fa-box"></i> Products
            </a>
        </li>
        <li>
            <a href="employee_categories.php" <?php echo (basename($_SERVER['PHP_SELF']) === 'employee_categories.php') ? 'class="active"' : ''; ?>>
                <i class="fas fa-list"></i> Categories
            </a>
        </li>
        <li>
            <a href="employee_events.php" <?php echo (basename($_SERVER['PHP_SELF']) === 'employee_events.php') ? 'class="active"' : ''; ?>>
                <i class="fas fa-calendar-alt"></i> Events
            </a>
        </li>
        <li>
            <a href="employee_profile.php" <?php echo (basename($_SERVER['PHP_SELF']) === 'employee_profile.php') ? 'class="active"' : ''; ?>>
                <i class="fas fa-user-cog"></i> My Profile
            </a>
        </li>
        <li style="border-top: 1px solid rgba(255,255,255,0.2); margin-top: 10px; padding-top: 10px;">
            
        </li>
        
    </nav>
</aside>
