<?php
// employee_profile.php
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    header('Location: employee_login.php');
    exit();
}

$employee_id = $_SESSION['user_id'];

// Check if trying to access another employee's profile
if (isset($_GET['id']) && intval($_GET['id']) != $employee_id) {
    die('Unauthorized access!');
}

$message = '';
$message_type = '';

// Get employee details - ONLY their own
$employee_query = mysqli_query($conn, "SELECT * FROM employee WHERE id = $employee_id");
$employee = mysqli_fetch_assoc($employee_query);

if (!$employee) {
    die('Employee not found!');
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name'] ?? '');
    $phone = mysqli_real_escape_string($conn, $_POST['phone'] ?? '');
    
    if (!empty($full_name)) {
        $update_query = "UPDATE employee SET full_name = '$full_name', phone = '$phone' WHERE id = $employee_id";
        if (mysqli_query($conn, $update_query)) {
            $_SESSION['full_name'] = $full_name;
            $_SESSION['phone'] = $phone;
            $message = 'Profile updated successfully!';
            $message_type = 'success';
            
            // Refresh employee data
            $employee_query = mysqli_query($conn, "SELECT * FROM employee WHERE id = $employee_id");
            $employee = mysqli_fetch_assoc($employee_query);
        } else {
            $message = 'Error updating profile: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    } else {
        $message = 'Please fill in all required fields';
        $message_type = 'error';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Employee Portal</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <?php include 'employee_sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-user-cog"></i> My Profile</h1>
                <span>Manage your profile information</span>
            </div>

            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>" style="margin-bottom: 20px;">
                <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                <?php echo $message; ?>
            </div>
            <?php endif; ?>

            <!-- Profile Information Card -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-user-circle"></i> Employee Information</h2>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 40px; margin-bottom: 30px;">
                    <!-- Profile Avatar Section -->
                    <div style="text-align: center;">
                        <div style="width: 150px; height: 150px; background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto; box-shadow: 0 4px 15px rgba(224, 123, 57, 0.3);">
                            <i class="fas fa-user" style="font-size: 4rem; color: white;"></i>
                        </div>
                        <h3 style="margin-top: 20px; color: #333;">
                            <?php echo htmlspecialchars($employee['full_name']); ?>
                        </h3>
                        <p style="color: #E07B39; margin: 5px 0;">
                            <i class="fas fa-badge"></i> ID: <?php echo $employee['id']; ?>
                        </p>
                        <div style="margin-top: 20px; padding: 20px; background: #f9f9f9; border-radius: 8px;">
                            <div style="margin: 10px 0; color: #666;">
                                <strong>Account Status:</strong>
                                <span style="color: #2ecc71; font-weight: 600;">
                                    <i class="fas fa-check-circle"></i> Active
                                </span>
                            </div>
                            <div style="margin: 10px 0; color: #666;">
                                <strong>Member Since:</strong>
                                <span>Today</span>
                            </div>
                        </div>
                    </div>

                    <!-- Edit Profile Form -->
                    <div>
                        <form method="POST" action="">
                            <div class="form-group">
                                <label><i class="fas fa-user"></i> Full Name</label>
                                <input type="text" name="full_name" class="form-control" 
                                       value="<?php echo htmlspecialchars($employee['full_name']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label><i class="fas fa-phone"></i> Phone Number</label>
                                <input type="tel" name="phone" class="form-control" 
                                       value="<?php echo htmlspecialchars($employee['phone'] ?? ''); ?>">
                            </div>

                            <div class="form-group">
                                <label><i class="fas fa-briefcase"></i> Position</label>
                                <input type="text" class="form-control" value="Employee" disabled>
                            </div>

                            <div class="form-group">
                                <button type="submit" name="update_profile" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Statistics Card -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="color: #E07B39;">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="stat-value">
                        <?php 
                            $orders_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM `order` WHERE employee_id = $employee_id"))['count'];
                            echo $orders_count;
                        ?>
                    </div>
                    <div class="stat-label">Orders Created</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="color: #2ecc71;">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div class="stat-value">
                        <?php 
                            $revenue_data = mysqli_fetch_assoc(mysqli_query($conn, "
                                SELECT SUM(od.quantity * p.price) as total 
                                FROM `order` o
                                JOIN order_detail od ON o.id = od.order_id
                                JOIN product p ON od.product_id = p.id
                                WHERE o.employee_id = $employee_id
                            "));
                            echo 'TZS ' . number_format($revenue_data['total'] ?? 0, 0);
                        ?>
                    </div>
                    <div class="stat-label">Total Revenue</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="color: #f39c12;">
                        <i class="fas fa-comments"></i>
                    </div>
                    <div class="stat-value">
                        <?php 
                            $feedback_count = mysqli_fetch_assoc(mysqli_query($conn, "
                                SELECT COUNT(*) as count FROM feedback f
                                WHERE f.customer_id IN (SELECT DISTINCT customer_id FROM `order` WHERE employee_id = $employee_id)
                            "))['count'];
                            echo $feedback_count;
                        ?>
                    </div>
                    <div class="stat-label">Feedback Received</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon" style="color: #9b59b6;">
                        <i class="fas fa-star"></i>
                    </div>
                    <div class="stat-value">
                        <?php 
                            $avg_rating = mysqli_fetch_assoc(mysqli_query($conn, "
                                SELECT AVG(rating) as avg_rating FROM feedback f
                                WHERE f.customer_id IN (SELECT DISTINCT customer_id FROM `order` WHERE employee_id = $employee_id)
                            "))['avg_rating'];
                            echo number_format($avg_rating ?? 0, 1);
                        ?>
                        /5
                    </div>
                    <div class="stat-label">Average Rating</div>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-link"></i> Quick Links</h2>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                    <a href="employee_orders.php" class="btn btn-primary" style="text-align: center; padding: 20px;">
                        <i class="fas fa-shopping-cart"></i><br>My Orders
                    </a>
                    <a href="employee_shifts.php" class="btn btn-primary" style="text-align: center; padding: 20px;">
                        <i class="fas fa-clock"></i><br>My Shifts
                    </a>
                    <a href="employee_feedback.php" class="btn btn-primary" style="text-align: center; padding: 20px;">
                        <i class="fas fa-comments"></i><br>Feedback
                    </a>
                    <a href="employee_dashboard.php" class="btn btn-secondary" style="text-align: center; padding: 20px;">
                        <i class="fas fa-home"></i><br>Dashboard
                    </a>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
