<?php
// user/user_dashboard.php
session_start();

if (!isset($_SESSION['customer_id'])) {
    header('Location: user_login.php');
    exit();
}

require_once '../config.php';

$customer_id = $_SESSION['customer_id'];
$customer_name = $_SESSION['customer_name'];

// Get customer's recent orders
$recent_orders = mysqli_query($conn, "
    SELECT o.id, o.order_date, o.status,
           SUM(od.quantity * p.price) as total,
           GROUP_CONCAT(p.product_name SEPARATOR ', ') as items
    FROM `order` o
    JOIN order_detail od ON o.id = od.order_id
    JOIN product p ON od.product_id = p.id
    WHERE o.customer_id = $customer_id
    GROUP BY o.id
    ORDER BY o.order_date DESC
    LIMIT 5
");

// Get customer's upcoming reservations
$upcoming_reservations = mysqli_query($conn, "
    SELECT r.id, r.reservation_date, s.service_name
    FROM reservation r
    JOIN service s ON r.service_id = s.id
    WHERE r.customer_id = $customer_id AND r.reservation_date >= CURDATE()
    ORDER BY r.reservation_date ASC
    LIMIT 5
");

// Get customer's event registrations
$event_registrations = mysqli_query($conn, "
    SELECT e.event_name, e.event_date, e.description
    FROM event_customer ec
    JOIN event e ON ec.event_id = e.id
    WHERE ec.customer_id = $customer_id AND e.event_date >= CURDATE()
    ORDER BY e.event_date ASC
    LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - Cafeteria</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, rgba(224, 123, 57, 0) 0%, rgba(200, 106, 47, 0) 100%), url('../customer.jpg') center/cover no-repeat;
            background-attachment: fixed;
        }

        .dashboard-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .welcome-section {
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }

        .welcome-section h1 {
            margin: 0;
            font-size: 2.5em;
        }

        .welcome-section p {
            margin: 10px 0 0 0;
            opacity: 0.9;
        }

        .menu-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .menu-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .menu-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }

        .menu-card-header {
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            color: white;
            padding: 20px;
            text-align: center;
        }

        .menu-card-header i {
            font-size: 2em;
            margin-bottom: 10px;
        }

        .menu-card-header h3 {
            margin: 0;
            font-size: 1.5em;
        }

        .menu-card-body {
            padding: 20px;
        }

        .menu-card-body p {
            color: #666;
            margin-bottom: 15px;
        }

        .menu-btn {
            display: block;
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            color: white;
            text-decoration: none;
            text-align: center;
            border-radius: 5px;
            transition: transform 0.2s;
        }

        .menu-btn:hover {
            transform: translateY(-2px);
        }

        .recent-activity {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .recent-activity h3 {
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #E07B39;
            padding-bottom: 10px;
        }

        .activity-item {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-item h4 {
            margin: 0 0 5px 0;
            color: #333;
        }

        .activity-item p {
            margin: 0;
            color: #666;
            font-size: 0.9em;
        }

        .status-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: bold;
        }

        .status-pending { background: #fff3cd; color: #856404; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }

        .logout-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .logout-btn:hover {
            background: #c82333;
        }
    </style>
</head>
<body>
    <a href="user_logout.php" class="logout-btn">Logout</a>

    <div class="dashboard-container">
        <div class="welcome-section">
            <h1>Welcome back, <?php echo htmlspecialchars($customer_name); ?>!</h1>
            <p>What would you like to do today?</p>
        </div>

        <div class="menu-grid">
            <div class="menu-card">
                <div class="menu-card-header">
                    <i class="fas fa-utensils"></i>
                    <h3>Order Food</h3>
                </div>
                <div class="menu-card-body">
                    <p>Browse our delicious menu and place your order online.</p>
                    <a href="menu.php" class="menu-btn">View Menu</a>
                </div>
            </div>

            <div class="menu-card">
                <div class="menu-card-header">
                    <i class="fas fa-calendar-alt"></i>
                    <h3>Events</h3>
                </div>
                <div class="menu-card-body">
                    <p>Check out upcoming events and register to attend.</p>
                    <a href="events.php" class="menu-btn">View Events</a>
                </div>
            </div>

            <div class="menu-card">
                <div class="menu-card-header">
                    <i class="fas fa-star"></i>
                    <h3>Feedback</h3>
                </div>
                <div class="menu-card-body">
                    <p>Share your experience and help us improve.</p>
                    <a href="feedback.php" class="menu-btn">Give Feedback</a>
                </div>
            </div>
        </div>

        <div class="recent-activity">
            <h3><i class="fas fa-history"></i> Recent Orders</h3>
            <?php if (mysqli_num_rows($recent_orders) > 0): ?>
                <?php while ($order = mysqli_fetch_assoc($recent_orders)): ?>
                    <div class="activity-item">
                        <h4>Order #<?php echo $order['id']; ?> - $<?php echo number_format($order['total'], 2); ?></h4>
                        <p><?php echo htmlspecialchars($order['items']); ?></p>
                        <p><small><?php echo date('M j, Y g:i A', strtotime($order['order_date'])); ?> -
                        <span class="status-badge status-<?php echo strtolower($order['status']); ?>">
                            <?php echo ucfirst($order['status']); ?>
                        </span></small></p>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No recent orders found.</p>
            <?php endif; ?>
        </div>

        <div class="recent-activity">
            <h3><i class="fas fa-calendar"></i> Upcoming Reservations</h3>
            <?php if (mysqli_num_rows($upcoming_reservations) > 0): ?>
                <?php while ($reservation = mysqli_fetch_assoc($upcoming_reservations)): ?>
                    <div class="activity-item">
                        <h4><?php echo htmlspecialchars($reservation['service_name']); ?></h4>
                        <p><small><?php echo date('M j, Y', strtotime($reservation['reservation_date'])); ?></small></p>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No upcoming reservations.</p>
            <?php endif; ?>
        </div>

        <div class="recent-activity">
            <h3><i class="fas fa-calendar-star"></i> Registered Events</h3>
            <?php if (mysqli_num_rows($event_registrations) > 0): ?>
                <?php while ($event = mysqli_fetch_assoc($event_registrations)): ?>
                    <div class="activity-item">
                        <h4><?php echo htmlspecialchars($event['event_name']); ?></h4>
                        <p><?php echo htmlspecialchars(substr($event['description'], 0, 100)); ?>...</p>
                        <p><small><?php echo date('M j, Y', strtotime($event['event_date'])); ?></small></p>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No upcoming event registrations.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>