<?php
// user/user_logout.php
session_start();

// Clear all customer session variables
unset($_SESSION['customer_id']);
unset($_SESSION['customer_name']);
unset($_SESSION['customer_phone']);

// Destroy the session
session_destroy();

// Redirect to login page
header('Location: user_login.php');
exit();
?>