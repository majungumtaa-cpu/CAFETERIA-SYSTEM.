<?php
// user/user_register.php
session_start();

// Redirect if already logged in
if (isset($_SESSION['customer_id'])) {
    header('Location: user_dashboard.php');
    exit();
}

require_once '../config.php';

// Handle registration form submission
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if (empty($full_name) || empty($phone)) {
        $error = 'Please fill in all fields';
    } elseif (!preg_match('/^[0-9+\-\s()]+$/', $phone)) {
        $error = 'Please enter a valid phone number';
    } else {
        // Check if customer already exists
        $stmt = mysqli_prepare($conn, "SELECT id FROM customer WHERE phone = ?");
        mysqli_stmt_bind_param($stmt, "s", $phone);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            $error = 'A customer with this phone number already exists';
        } else {
            // Insert new customer
            $stmt = mysqli_prepare($conn, "INSERT INTO customer (full_name, phone) VALUES (?, ?)");
            mysqli_stmt_bind_param($stmt, "ss", $full_name, $phone);

            if (mysqli_stmt_execute($stmt)) {
                $customer_id = mysqli_insert_id($conn);
                $_SESSION['customer_id'] = $customer_id;
                $_SESSION['customer_name'] = $full_name;
                $_SESSION['customer_phone'] = $phone;
                header('Location: user_dashboard.php');
                exit();
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
        mysqli_stmt_close($stmt);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Registration - Cafeteria</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .register-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(135deg, rgba(224, 123, 57, 0) 0%, rgba(200, 106, 47, 0) 100%), url('../login.jpg') center/cover no-repeat;
            background-attachment: fixed;
            padding: 20px;
        }

        .register-box {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
        }

        .register-box h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: 500;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-group input:focus {
            outline: none;
            border-color: #E07B39;
            box-shadow: 0 0 5px rgba(224, 123, 57, 0.3);
        }

        .register-btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .register-btn:hover {
            transform: translateY(-2px);
        }

        .error {
            background: #fee;
            color: #c33;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .success {
            background: #efe;
            color: #363;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .login-link {
            text-align: center;
            margin-top: 20px;
        }

        .login-link a {
            color: #E07B39;
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-box">
            <h2><i class="fas fa-user-plus"></i> Customer Registration</h2>

            <?php if ($error): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="full_name">Full Name:</label>
                    <input type="text" id="full_name" name="full_name" required placeholder="Enter your full name">
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number:</label>
                    <input type="tel" id="phone" name="phone" required placeholder="Enter your phone number">
                </div>

                <button type="submit" class="register-btn">Register</button>
            </form>

            <div class="login-link">
                <p>Already have an account? <a href="user_login.php">Login here</a></p>
            </div>
        </div>
    </div>
</body>
</html>