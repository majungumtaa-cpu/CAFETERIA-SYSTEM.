<?php
// user/cart.php
session_start();

if (!isset($_SESSION['customer_id'])) {
    header('Location: user_login.php');
    exit();
}

require_once '../config.php';

$customer_id = $_SESSION['customer_id'];

// Handle cart updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_cart'])) {
        foreach ($_POST['quantities'] as $product_id => $quantity) {
            $quantity = (int)$quantity;
            if ($quantity <= 0) {
                unset($_SESSION['cart'][$product_id]);
            } else {
                $_SESSION['cart'][$product_id] = $quantity;
            }
        }
    } elseif (isset($_POST['remove_item'])) {
        $product_id = (int)$_POST['product_id'];
        unset($_SESSION['cart'][$product_id]);
    } elseif (isset($_POST['clear_cart'])) {
        unset($_SESSION['cart']);
    } elseif (isset($_POST['place_order'])) {
        // Redirect to checkout
        header('Location: checkout.php');
        exit();
    }
}

// Get cart items with product details
$cart_items = array();
$total = 0;

if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $product_ids = array_keys($_SESSION['cart']);
    $ids_string = implode(',', $product_ids);

    $products = mysqli_query($conn, "
        SELECT p.id, p.product_name, p.price, p.quantity as stock_quantity,
               mc.category_name
        FROM product p
        JOIN menu_category mc ON p.category_id = mc.id
        WHERE p.id IN ($ids_string)
    ");

    while ($product = mysqli_fetch_assoc($products)) {
        $product_id = $product['id'];
        $quantity = $_SESSION['cart'][$product_id];

        // Check if quantity exceeds stock
        if ($quantity > $product['stock_quantity']) {
            $quantity = $product['stock_quantity'];
            $_SESSION['cart'][$product_id] = $quantity;
        }

        $subtotal = $quantity * $product['price'];
        $total += $subtotal;

        $cart_items[] = array(
            'id' => $product_id,
            'name' => $product['product_name'],
            'price' => $product['price'],
            'quantity' => $quantity,
            'stock' => $product['stock_quantity'],
            'subtotal' => $subtotal,
            'category' => $product['category_name']
        );
    }
}

$cart_count = count($cart_items);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - Cafeteria</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, rgba(224, 123, 57, 0) 0%, rgba(200, 106, 47, 0) 100%), url('../customer.jpg') center/cover no-repeat;
            background-attachment: fixed;
        }

        .cart-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }

        .cart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
        }

        .cart-header h1 {
            margin: 0;
        }

        .cart-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: transform 0.2s;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .btn-primary {
            background: #28a745;
            color: white;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .empty-cart {
            text-align: center;
            padding: 50px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .empty-cart i {
            font-size: 4em;
            color: #ccc;
            margin-bottom: 20px;
        }

        .cart-table {
            width: 100%;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 20px;
        }

        .cart-table th,
        .cart-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .cart-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
        }

        .cart-table tr:last-child td {
            border-bottom: none;
        }

        .product-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .product-image {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5em;
        }

        .product-details h4 {
            margin: 0 0 5px 0;
            color: #333;
        }

        .product-details small {
            color: #666;
        }

        .quantity-input {
            width: 60px;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-align: center;
        }

        .remove-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9em;
        }

        .remove-btn:hover {
            background: #c82333;
        }

        .cart-total {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 20px;
            text-align: right;
        }

        .cart-total h3 {
            margin: 0 0 15px 0;
            color: #333;
            font-size: 1.5em;
        }

        .total-amount {
            font-size: 1.8em;
            font-weight: bold;
            color: #E07B39;
        }

        .checkout-section {
            margin-top: 20px;
            text-align: center;
        }

        .checkout-btn {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.2em;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .checkout-btn:hover {
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="cart-container">
        <div class="cart-header">
            <h1><i class="fas fa-shopping-cart"></i> Shopping Cart</h1>
            <div class="cart-actions">
                <a href="menu.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Continue Shopping
                </a>
                <?php if ($cart_count > 0): ?>
                    <form method="POST" style="display: inline;">
                        <button type="submit" name="clear_cart" class="btn btn-danger" onclick="return confirm('Are you sure you want to clear your cart?')">
                            <i class="fas fa-trash"></i> Clear Cart
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($cart_count == 0): ?>
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h2>Your cart is empty</h2>
                <p>Add some delicious items from our menu!</p>
                <a href="menu.php" class="btn btn-primary">
                    <i class="fas fa-utensils"></i> Browse Menu
                </a>
            </div>
        <?php else: ?>
            <form method="POST">
                <table class="cart-table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart_items as $item): ?>
                            <tr>
                                <td>
                                    <div class="product-info">
                                        <div class="product-image">
                                            <i class="fas fa-utensils"></i>
                                        </div>
                                        <div class="product-details">
                                            <h4><?php echo htmlspecialchars($item['name']); ?></h4>
                                            <small><?php echo htmlspecialchars($item['category']); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>$<?php echo number_format($item['price'], 2); ?></td>
                                <td>
                                    <input type="number" name="quantities[<?php echo $item['id']; ?>]"
                                           value="<?php echo $item['quantity']; ?>" min="1"
                                           max="<?php echo $item['stock']; ?>" class="quantity-input">
                                </td>
                                <td>$<?php echo number_format($item['subtotal'], 2); ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                        <button type="submit" name="remove_item" class="remove-btn"
                                                onclick="return confirm('Remove this item from cart?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div style="text-align: center; margin: 20px 0;">
                    <button type="submit" name="update_cart" class="btn btn-primary">
                        <i class="fas fa-sync"></i> Update Cart
                    </button>
                </div>
            </form>

            <div class="cart-total">
                <h3>Cart Total</h3>
                <div class="total-amount">$<?php echo number_format($total, 2); ?></div>

                <div class="checkout-section">
                    <form method="POST">
                        <button type="submit" name="place_order" class="checkout-btn">
                            <i class="fas fa-credit-card"></i> Proceed to Checkout
                        </button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>