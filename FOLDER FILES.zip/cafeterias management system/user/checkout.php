<?php
// user/checkout.php
session_start();

if (!isset($_SESSION['customer_id'])) {
    header('Location: user_login.php');
    exit();
}

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit();
}

require_once '../config.php';

$customer_id = $_SESSION['customer_id'];
$customer_name = $_SESSION['customer_name'];
$customer_phone = $_SESSION['customer_phone'];

$error = '';
$success = '';

// Get cart items with product details
$cart_items = array();
$total = 0;
$has_insufficient_stock = false;

if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $product_ids = array_keys($_SESSION['cart']);
    $ids_string = implode(',', $product_ids);

    $products = mysqli_query($conn, "
        SELECT p.id, p.product_name, p.price, p.quantity as stock_quantity,
               mc.category_name
        FROM product p
        JOIN menu_category mc ON p.category_id = mc.id
        WHERE p.id IN ($ids_string)
    ");

    while ($product = mysqli_fetch_assoc($products)) {
        $product_id = $product['id'];
        $quantity = $_SESSION['cart'][$product_id];

        // Check stock availability
        if ($quantity > $product['stock_quantity']) {
            $has_insufficient_stock = true;
            $quantity = $product['stock_quantity'];
            $_SESSION['cart'][$product_id] = $quantity;
        }

        if ($quantity > 0) {
            $subtotal = $quantity * $product['price'];
            $total += $subtotal;

            $cart_items[] = array(
                'id' => $product_id,
                'name' => $product['product_name'],
                'price' => $product['price'],
                'quantity' => $quantity,
                'stock' => $product['stock_quantity'],
                'subtotal' => $subtotal,
                'category' => $product['category_name']
            );
        }
    }
}

// Get available employees for order assignment
$employees = mysqli_query($conn, "SELECT id, full_name FROM employee ORDER BY full_name");

// Handle order placement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    if ($has_insufficient_stock) {
        $error = 'Some items in your cart have insufficient stock. Please update your cart.';
    } elseif (empty($cart_items)) {
        $error = 'Your cart is empty.';
    } else {
        $employee_id = (int)$_POST['employee_id'];
        $order_notes = trim($_POST['order_notes'] ?? '');

        // Check if employees exist
        $employee_check = mysqli_query($conn, "SELECT COUNT(*) as count FROM employee");
        $employee_count = mysqli_fetch_assoc($employee_check)['count'];

        // If no employees exist, allow order creation without employee
        if ($employee_count == 0) {
            $employee_id = null; // Set to null
        } elseif ($employee_id == 0) {
            $error = 'Please select an employee to handle your order.';
            goto end;
        }

        // Verify employee exists (only if employee_id is not null)
        if ($employee_id !== null) {
            $emp_check = mysqli_query($conn, "SELECT id FROM employee WHERE id = $employee_id");
            if (mysqli_num_rows($emp_check) == 0) {
                $error = 'Invalid employee selected.';
                goto end;
            }
        }

        // Start transaction
        mysqli_begin_transaction($conn);

        try {
            // Insert order
            if ($employee_id === null) {
                $order_query = "INSERT INTO `order` (customer_id, order_date, status) VALUES (?, NOW(), 'pending')";
                $stmt = mysqli_prepare($conn, $order_query);
                mysqli_stmt_bind_param($stmt, "i", $customer_id);
            } else {
                $order_query = "INSERT INTO `order` (customer_id, employee_id, order_date, status) VALUES (?, ?, NOW(), 'pending')";
                $stmt = mysqli_prepare($conn, $order_query);
                mysqli_stmt_bind_param($stmt, "ii", $customer_id, $employee_id);
            }
                mysqli_stmt_execute($stmt);
                $order_id = mysqli_insert_id($conn);
                mysqli_stmt_close($stmt);

                // Insert order details and update stock
                foreach ($cart_items as $item) {
                    // Insert order detail
                    $detail_query = "INSERT INTO order_detail (order_id, product_id, quantity) VALUES (?, ?, ?)";
                    $stmt = mysqli_prepare($conn, $detail_query);
                    mysqli_stmt_bind_param($stmt, "iii", $order_id, $item['id'], $item['quantity']);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);

                    // Update product stock
                    $update_stock = "UPDATE product SET quantity = quantity - ? WHERE id = ?";
                    $stmt = mysqli_prepare($conn, $update_stock);
                    mysqli_stmt_bind_param($stmt, "ii", $item['quantity'], $item['id']);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }

                // Clear cart
                unset($_SESSION['cart']);

                // Commit transaction
                mysqli_commit($conn);

                // Log activity: order created
                $details_arr = [];
                foreach ($cart_items as $it) {
                    $details_arr[] = $it['id'] . 'x' . $it['quantity'];
                }
                $details = 'customer:' . $customer_name . ';items:' . implode(',', $details_arr) . ';total:' . number_format($total,2);
                if (function_exists('log_activity')) {
                    log_activity($conn, 'add', 'order', $order_id, $details);
                }

                $success = 'Order placed successfully! Order #' . $order_id;
                $cart_items = array(); // Clear display

            } catch (Exception $e) {
                mysqli_rollback($conn);
                $error = 'Failed to place order. Please try again.';
            }
        }
    }

    end:
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Cafeteria</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, rgba(224, 123, 57, 0) 0%, rgba(200, 106, 47, 0) 100%), url('../customer.jpg') center/cover no-repeat;
            background-attachment: fixed;
        }

        .checkout-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }

        .checkout-header {
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }

        .checkout-header h1 {
            margin: 0;
        }

        .checkout-content {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }

        .order-summary, .customer-info {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            padding: 20px;
        }

        .order-summary h3, .customer-info h3 {
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #E07B39;
            padding-bottom: 10px;
        }

        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .summary-item:last-child {
            border-bottom: none;
            font-weight: bold;
            font-size: 1.1em;
            color: #E07B39;
        }

        .customer-details {
            margin-bottom: 20px;
        }

        .customer-details p {
            margin: 5px 0;
            color: #666;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: 500;
        }

        .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .place-order-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1.2em;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .place-order-btn:hover {
            transform: translateY(-2px);
        }

        .place-order-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
            transform: none;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .back-btn {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .back-btn:hover {
            background: #5a6268;
        }

        @media (max-width: 768px) {
            .checkout-content {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="checkout-container">
        <a href="cart.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Cart</a>

        <div class="checkout-header">
            <h1><i class="fas fa-credit-card"></i> Checkout</h1>
        </div>

        <?php if ($error): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-message">
                <i class="fas fa-check"></i> <?php echo htmlspecialchars($success); ?>
                <br><a href="user_dashboard.php" style="color: #155724; text-decoration: underline;">Return to Dashboard</a>
            </div>
        <?php endif; ?>

        <?php if (!empty($cart_items) && !$success): ?>
            <div class="checkout-content">
                <div class="customer-info">
                    <h3><i class="fas fa-user"></i> Order Information</h3>

                    <div class="customer-details">
                        <p><strong>Customer:</strong> <?php echo htmlspecialchars($customer_name); ?></p>
                        <p><strong>Phone:</strong> <?php echo htmlspecialchars($customer_phone); ?></p>
                    </div>

                    <form method="POST">
                        <div class="form-group">
                            <label for="employee_id">Select Employee:</label>
                            <select name="employee_id" id="employee_id" <?php echo ($employees && mysqli_num_rows($employees) > 0) ? 'required' : ''; ?>>
                                <option value="">Choose an employee to handle your order</option>
                                <?php
                                if ($employees && mysqli_num_rows($employees) > 0) {
                                    mysqli_data_seek($employees, 0); // Reset pointer
                                    while ($employee = mysqli_fetch_assoc($employees)):
                                ?>
                                    <option value="<?php echo $employee['id']; ?>">
                                        <?php echo htmlspecialchars($employee['full_name']); ?>
                                    </option>
                                <?php
                                    endwhile;
                                } else {
                                    echo '<option value="" disabled>No employees available</option>';
                                }
                                ?>
                            </select>
                            <?php if (!$employees || mysqli_num_rows($employees) == 0): ?>
                            <small class="text-muted">No employees available. Your order will be processed automatically.</small>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="order_notes">Order Notes (Optional):</label>
                            <textarea name="order_notes" id="order_notes" placeholder="Any special instructions for your order..."></textarea>
                        </div>

                        <button type="submit" name="place_order" class="place-order-btn">
                            <i class="fas fa-shopping-cart"></i> Place Order - $<?php echo number_format($total, 2); ?>
                        </button>
                    </form>
                </div>

                <div class="order-summary">
                    <h3><i class="fas fa-list"></i> Order Summary</h3>

                    <?php foreach ($cart_items as $item): ?>
                        <div class="summary-item">
                            <span><?php echo htmlspecialchars($item['name']); ?> (x<?php echo $item['quantity']; ?>)</span>
                            <span>$<?php echo number_format($item['subtotal'], 2); ?></span>
                        </div>
                    <?php endforeach; ?>

                    <div class="summary-item">
                        <span><strong>Total Amount</strong></span>
                        <span><strong>$<?php echo number_format($total, 2); ?></strong></span>
                    </div>
                </div>
            </div>
        <?php elseif (!$success): ?>
            <div style="text-align: center; padding: 50px;">
                <i class="fas fa-shopping-cart" style="font-size: 3em; color: #ccc;"></i>
                <h3 style="color: #666;">Your cart is empty.</h3>
                <a href="menu.php" class="btn btn-primary" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background: #E07B39; color: white; text-decoration: none; border-radius: 5px;">
                    <i class="fas fa-utensils"></i> Browse Menu
                </a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>