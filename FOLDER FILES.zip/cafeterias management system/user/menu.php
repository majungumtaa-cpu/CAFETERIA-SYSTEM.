<?php
// user/menu.php
session_start();

if (!isset($_SESSION['customer_id'])) {
    header('Location: user_login.php');
    exit();
}

require_once '../config.php';

$customer_id = $_SESSION['customer_id'];

// Get all menu categories and products
$categories = mysqli_query($conn, "
    SELECT mc.id, mc.category_name,
           COUNT(p.id) as product_count
    FROM menu_category mc
    LEFT JOIN product p ON mc.id = p.category_id
    GROUP BY mc.id, mc.category_name
    ORDER BY mc.category_name
");

// Get products by category
$products_by_category = array();
$categories_result = mysqli_query($conn, "SELECT * FROM menu_category ORDER BY category_name");
while ($category = mysqli_fetch_assoc($categories_result)) {
    $category_id = $category['id'];
    $products = mysqli_query($conn, "
        SELECT p.*, mc.category_name
        FROM product p
        JOIN menu_category mc ON p.category_id = mc.id
        WHERE p.category_id = $category_id AND p.quantity > 0
        ORDER BY p.product_name
    ");
    $products_by_category[$category_id] = array(
        'category' => $category,
        'products' => $products
    );
}

// Handle add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = $quantity;
    }

    $success_message = "Product added to cart!";
}

// Get cart count
$cart_count = 0;
if (isset($_SESSION['cart'])) {
    $cart_count = array_sum($_SESSION['cart']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - Cafeteria</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, rgba(224, 123, 57, 0) 0%, rgba(200, 106, 47, 0) 100%), url('../customer.jpg') center/cover no-repeat;
            background-attachment: fixed;
        }

        .menu-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .menu-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
        }

        .menu-header h1 {
            margin: 0;
        }

        .cart-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .cart-btn {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .cart-btn:hover {
            background: #218838;
        }

        .cart-count {
            background: #dc3545;
            color: white;
            border-radius: 50%;
            padding: 2px 8px;
            font-size: 0.8em;
            margin-left: 5px;
        }

        .category-section {
            margin-bottom: 40px;
        }

        .category-title {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 5px solid #E07B39;
        }

        .category-title h2 {
            margin: 0;
            color: #333;
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        .product-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }

        .product-image {
            height: 200px;
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 3em;
        }

        .product-info {
            padding: 20px;
        }

        .product-name {
            font-size: 1.3em;
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
        }

        .product-price {
            font-size: 1.2em;
            color: #E07B39;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .product-stock {
            color: #666;
            font-size: 0.9em;
            margin-bottom: 15px;
        }

        .add-to-cart-form {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .quantity-input {
            width: 60px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .add-btn {
            background: linear-gradient(135deg, #E07B39 0%, #C86A2F 100%);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .add-btn:hover {
            transform: translateY(-2px);
        }

        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
        }

        .back-btn {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .back-btn:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>
    <div class="menu-container">
        <a href="user_dashboard.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>

        <div class="menu-header">
            <h1><i class="fas fa-utensils"></i> Our Menu</h1>
            <div class="cart-info">
                <a href="cart.php" class="cart-btn">
                    <i class="fas fa-shopping-cart"></i> View Cart
                    <?php if ($cart_count > 0): ?>
                        <span class="cart-count"><?php echo $cart_count; ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>

        <?php if (isset($success_message)): ?>
            <div class="success-message">
                <i class="fas fa-check"></i> <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>

        <?php foreach ($products_by_category as $category_id => $data): ?>
            <?php if (mysqli_num_rows($data['products']) > 0): ?>
                <div class="category-section">
                    <div class="category-title">
                        <h2><?php echo htmlspecialchars($data['category']['category_name']); ?></h2>
                    </div>

                    <div class="products-grid">
                        <?php while ($product = mysqli_fetch_assoc($data['products'])): ?>
                            <div class="product-card">
                                <div class="product-image">
                                    <i class="fas fa-utensils"></i>
                                </div>
                                <div class="product-info">
                                    <div class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></div>
                                    <div class="product-price">$<?php echo number_format($product['price'], 2); ?></div>
                                    <div class="product-stock">Available: <?php echo $product['quantity']; ?> units</div>

                                    <form method="POST" class="add-to-cart-form">
                                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                        <input type="number" name="quantity" value="1" min="1" max="<?php echo $product['quantity']; ?>" class="quantity-input" required>
                                        <button type="submit" name="add_to_cart" class="add-btn">
                                            <i class="fas fa-cart-plus"></i> Add
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>

        <?php if (empty($products_by_category)): ?>
            <div style="text-align: center; padding: 50px;">
                <i class="fas fa-utensils" style="font-size: 3em; color: #ccc;"></i>
                <h3 style="color: #666;">No products available at the moment.</h3>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>