<?php
// products.php - Enhanced with prepared statements
require_once 'config.php';
check_login();

// Prevent employees from accessing this page
if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'employee') {
    header('Location: employee_dashboard.php');
    exit();
}

$message = '';
$message_type = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_product'])) {
        $product_name = $_POST['product_name'];
        $category_id = intval($_POST['category_id']);
        $price = floatval($_POST['price']);
        $quantity = intval($_POST['quantity']);
        
        // Using prepared statement
        $stmt = mysqli_prepare($conn, 
            "INSERT INTO product (product_name, category_id, price, quantity) 
             VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sidi", $product_name, $category_id, $price, $quantity);
        
        if (mysqli_stmt_execute($stmt)) {
            $message = 'Product added successfully!';
            $message_type = 'success';
            if (function_exists('log_activity')) {
                $new_id = mysqli_insert_id($conn);
                $details = 'name:' . $product_name . ';price:' . $price . ';quantity:' . $quantity;
                log_activity($conn, 'add', 'product', $new_id, $details);
            }
        } else {
            $message = 'Error adding product: ' . mysqli_error($conn);
            $message_type = 'error';
        }
        mysqli_stmt_close($stmt);
    }
    
    if (isset($_POST['delete_product'])) {
        $product_id = intval($_POST['product_id']);
        
        // Check if product has related records
        $stmt = mysqli_prepare($conn, 
            "SELECT (SELECT 1 FROM order_detail WHERE product_id = ? LIMIT 1) 
             OR (SELECT 1 FROM purchase WHERE product_id = ? LIMIT 1) as has_records");
        mysqli_stmt_bind_param($stmt, "ii", $product_id, $product_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $row = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);
        
        if ($row['has_records']) {
            $message = 'Cannot delete product. It has associated orders or purchases!<br>Set quantity to 0 instead.';
            $message_type = 'error';
        } else {
            $stmt = mysqli_prepare($conn, "DELETE FROM product WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "i", $product_id);
            
            if (mysqli_stmt_execute($stmt)) {
                $message = 'Product deleted successfully!';
                $message_type = 'success';
                if (function_exists('log_activity')) {
                    log_activity($conn, 'delete', 'product', $product_id, 'Product deleted');
                }
            } else {
                $message = 'Error deleting product: ' . mysqli_error($conn);
                $message_type = 'error';
            }
            mysqli_stmt_close($stmt);
        }
    }
    
    if (isset($_POST['update_stock'])) {
        $product_id = intval($_POST['product_id']);
        $new_quantity = intval($_POST['new_quantity']);
        
        $stmt = mysqli_prepare($conn, "UPDATE product SET quantity = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "ii", $new_quantity, $product_id);
        
        if (mysqli_stmt_execute($stmt)) {
            $message = 'Stock updated successfully!';
            $message_type = 'success';
            if (function_exists('log_activity')) {
                // get old quantity if possible
                $res_old = mysqli_query($conn, "SELECT quantity FROM product WHERE id = $product_id LIMIT 1");
                $old_qty = null;
                if ($res_old && mysqli_num_rows($res_old) > 0) {
                    $old_qty = mysqli_fetch_assoc($res_old)['quantity'];
                }
                $details = 'old_qty:' . ($old_qty !== null ? $old_qty : 'unknown') . '->new_qty:' . $new_quantity;
                log_activity($conn, 'update', 'product', $product_id, $details);
            }
        } else {
            $message = 'Error updating stock: ' . mysqli_error($conn);
            $message_type = 'error';
        }
        mysqli_stmt_close($stmt);
    }
}

// Fetch products with categories
// Filters for products (status: in_stock/low_stock/out_of_stock, date: created_at if available)
$status_filter = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : '';
$date_filter = isset($_GET['date']) ? mysqli_real_escape_string($conn, $_GET['date']) : '';

$product_query = "SELECT p.*, mc.category_name FROM product p JOIN menu_category mc ON p.category_id = mc.id WHERE 1=1";

// Apply status filter based on quantity thresholds
if ($status_filter && $status_filter !== '') {
    if ($status_filter === 'in_stock') {
        $product_query .= " AND p.quantity >= 20";
    } elseif ($status_filter === 'low_stock') {
        $product_query .= " AND p.quantity < 20 AND p.quantity > 0";
    } elseif ($status_filter === 'out_of_stock') {
        $product_query .= " AND p.quantity = 0";
    }
}

// Apply date filter only if the column exists
if ($date_filter && $date_filter !== '') {
    $col_check = mysqli_query($conn, "SHOW COLUMNS FROM product LIKE 'created_at'");
    if (mysqli_num_rows($col_check) > 0) {
        $product_query .= " AND DATE(p.created_at) = '$date_filter'";
    }
}

$product_query .= " ORDER BY p.id DESC";
$products = mysqli_query($conn, $product_query);

// Fetch categories for dropdown
$categories = mysqli_query($conn, "SELECT * FROM menu_category");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Add responsive design for mobile */
        @media (max-width: 768px) {
            .table-container {
                overflow-x: auto;
            }
            .data-table td, .data-table th {
                padding: 8px 5px;
                font-size: 14px;
            }
            .btn-sm {
                padding: 3px 8px;
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-utensils"></i> Product Management</h1>
                <button onclick="document.getElementById('addProductModal').style.display='block'" 
                        class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add Product
                </button>
            </div>
            
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <!-- Low Stock Warning -->
            <?php
            $low_stock_query = mysqli_query($conn, 
                "SELECT COUNT(*) as count FROM product WHERE quantity < 5 AND quantity > 0");
            $low_stock = mysqli_fetch_assoc($low_stock_query);
            if ($low_stock['count'] > 0): ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                You have <?php echo $low_stock['count']; ?> products with very low stock (< 5 units)!
            </div>
            <?php endif; ?>

            <!-- Filters -->
            <div class="card">
                <h3>Filters</h3>
                <form method="GET" action="products.php" style="display:flex; gap:10px; flex-wrap:wrap; align-items:flex-end;">
                    <div>
                        <label for="status_filter">Status:</label>
                        <select name="status" id="status_filter" class="form-control" style="width: 180px;">
                            <option value="">All Status</option>
                            <option value="in_stock" <?php echo $status_filter == 'in_stock' ? 'selected' : ''; ?>>In Stock</option>
                            <option value="low_stock" <?php echo $status_filter == 'low_stock' ? 'selected' : ''; ?>>Low Stock</option>
                            <option value="out_of_stock" <?php echo $status_filter == 'out_of_stock' ? 'selected' : ''; ?>>Out of Stock</option>
                        </select>
                    </div>

                    <div>
                        <label for="date_filter">Date (created):</label>
                        <input type="date" name="date" id="date_filter" value="<?php echo htmlspecialchars($date_filter); ?>" class="form-control" style="width: 180px;">
                    </div>

                    <div>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                        <a href="products.php" class="btn btn-secondary"><i class="fas fa-redo"></i> Clear</a>
                    </div>
                </form>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2>All Products</h2>
                    <span><?php echo mysqli_num_rows($products); ?> products</span>
                </div>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($product = mysqli_fetch_assoc($products)): 
                                $status_class = '';
                                $status_text = '';
                                if ($product['quantity'] >= 20) {
                                    $status_class = 'status-active';
                                    $status_text = 'In Stock';
                                } elseif ($product['quantity'] > 0) {
                                    $status_class = 'status-pending';
                                    $status_text = 'Low Stock';
                                } else {
                                    $status_class = 'status-inactive';
                                    $status_text = 'Out of Stock';
                                }
                            ?>
                            <tr>
                                <td>#<?php echo str_pad($product['id'], 3, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                                <td>TZS <?php echo number_format($product['price'], 2); ?></td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                        <input type="number" name="new_quantity" value="<?php echo $product['quantity']; ?>" 
                                               style="width: 80px; padding: 2px 5px;" min="0" required>
                                        <button type="submit" name="update_stock" class="btn btn-sm btn-success">
                                            <i class="fas fa-sync"></i> Update
                                        </button>
                                    </form>
                                </td>
                                <td><span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span></td>
                                <td>
                                    <div style="display: flex; gap: 5px;">
                                        <button onclick="editProduct(<?php echo $product['id']; ?>)" 
                                                class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                            <button type="submit" name="delete_product" 
                                                    class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Are you sure you want to delete this product?\n\nNote: If product has orders, set quantity to 0 instead.')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            <?php if(mysqli_num_rows($products) == 0): ?>
                            <tr>
                                <td colspan="7" style="text-align: center; padding: 20px;">
                                    <i class="fas fa-box-open" style="font-size: 48px; color: #ccc; margin-bottom: 10px;"></i><br>
                                    No products found. Add your first product!
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Inventory Summary -->
            <div class="card">
                <div class="card-header">
                    <h2><i class="fas fa-chart-pie"></i> Inventory Summary</h2>
                </div>
                <div class="stats-grid">
                    <?php
                    // Reset queries with better calculations
                    $stats_query = mysqli_query($conn, "
                        SELECT 
                            SUM(CASE WHEN quantity >= 20 THEN 1 ELSE 0 END) as in_stock,
                            SUM(CASE WHEN quantity < 20 AND quantity > 0 THEN 1 ELSE 0 END) as low_stock,
                            SUM(CASE WHEN quantity = 0 THEN 1 ELSE 0 END) as out_of_stock,
                            SUM(price * quantity) as total_value
                        FROM product
                    ");
                    $stats = mysqli_fetch_assoc($stats_query);
                    ?>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="color: #2ecc71;">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stat-value"><?php echo $stats['in_stock'] ?? 0; ?></div>
                        <div class="stat-label">In Stock</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="color: #f39c12;">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div class="stat-value"><?php echo $stats['low_stock'] ?? 0; ?></div>
                        <div class="stat-label">Low Stock</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="color: #e74c3c;">
                            <i class="fas fa-times-circle"></i>
                        </div>
                        <div class="stat-value"><?php echo $stats['out_of_stock'] ?? 0; ?></div>
                        <div class="stat-label">Out of Stock</div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon" style="color: #E07B39;">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                        <div class="stat-value">TZS <?php echo number_format($stats['total_value'] ?? 0, 2); ?></div>
                        <div class="stat-label">Total Value</div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Add Product Modal -->
    <div id="addProductModal" style="display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
        <div style="background-color: white; margin: 5% auto; padding: 20px; width: 80%; max-width: 500px; border-radius: 5px; box-shadow: 0 4px 20px rgba(0,0,0,0.2);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="margin: 0;">Add New Product</h2>
                <span style="cursor: pointer; font-size: 28px; color: #666;" 
                      onclick="document.getElementById('addProductModal').style.display='none'">&times;</span>
            </div>
            
            <form method="POST">
                <div class="form-group">
                    <label>Product Name *</label>
                    <input type="text" name="product_name" class="form-control" required maxlength="255">
                </div>
                
                <div class="form-group">
                    <label>Category *</label>
                    <select name="category_id" class="form-control" required>
                        <option value="">Select Category</option>
                        <?php 
                        // Reset categories pointer
                        mysqli_data_seek($categories, 0);
                        while($category = mysqli_fetch_assoc($categories)): ?>
                        <option value="<?php echo $category['id']; ?>">
                            <?php echo htmlspecialchars($category['category_name']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group" style="flex: 1;">
                        <label>Price ($) *</label>
                        <input type="number" name="price" class="form-control" step="0.01" min="0.01" required>
                    </div>
                    <div class="form-group" style="flex: 1;">
                        <label>Initial Quantity *</label>
                        <input type="number" name="quantity" class="form-control" min="0" required>
                    </div>
                </div>
                
                <div class="form-group" style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="submit" name="add_product" class="btn btn-primary" style="flex: 1;">
                        <i class="fas fa-save"></i> Save Product
                    </button>
                    <button type="button" class="btn btn-secondary" style="flex: 1;"
                            onclick="document.getElementById('addProductModal').style.display='none'">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function editProduct(productId) {
        // In a real implementation, you would fetch product details via AJAX
        // and populate an edit modal
        
        // For now, redirect to an edit page or show a simple edit form
        window.location.href = 'edit_product.php?id=' + productId;
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
        var modal = document.getElementById('addProductModal');
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
    </script>
</body>
</html>