<?php
// edit_product.php
require_once 'config.php';
check_login();

$message = '';
$message_type = '';
$product = null;

// Get product ID from URL
$product_id = intval($_GET['id'] ?? 0);

if ($product_id <= 0) {
    header('Location: products.php');
    exit;
}

// Fetch product details
$result = mysqli_query($conn, "SELECT * FROM product WHERE id = $product_id");
if (!$result || mysqli_num_rows($result) == 0) {
    header('Location: products.php');
    exit;
}
$product = mysqli_fetch_assoc($result);

// Fetch categories for dropdown
$categories = mysqli_query($conn, "SELECT id, category_name FROM menu_category ORDER BY category_name");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_product'])) {
    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $category_id = intval($_POST['category_id']);
    $price = floatval($_POST['price']);
    
    // Validate inputs
    if (empty($product_name)) {
        $message = 'Product name is required!';
        $message_type = 'error';
    } elseif ($category_id <= 0) {
        $message = 'Please select a category!';
        $message_type = 'error';
    } elseif ($price < 0) {
        $message = 'Price cannot be negative!';
        $message_type = 'error';
    } else {
        // prepare details for audit from old product
        $old_product = $product;
        $sql = "UPDATE product SET product_name = '$product_name', category_id = $category_id, 
                price = $price WHERE id = $product_id";
        if (mysqli_query($conn, $sql)) {
            $message = 'Product updated successfully!';
            $message_type = 'success';
            // Refresh product data
            $result = mysqli_query($conn, "SELECT * FROM product WHERE id = $product_id");
            $product = mysqli_fetch_assoc($result);
            if (function_exists('log_activity')) {
                $details = 'name:' . ($old_product['product_name'] ?? '') . '->' . $product_name
                         . ';price:' . ($old_product['price'] ?? '') . '->' . $price
                         . ';category:' . ($old_product['category_id'] ?? '') . '->' . $category_id;
                log_activity($conn, 'update', 'product', $product_id, $details);
            }
        } else {
            $message = 'Error updating product: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Cafeteria Management</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <div class="container">
        <?php include 'sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-edit"></i> Edit Product</h1>
                <a href="products.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Products
                </a>
            </div>
            
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <?php if ($product): ?>
            <div class="card">
                <div class="card-header">
                    <h2>Edit Product #<?php echo str_pad($product['id'], 3, '0', STR_PAD_LEFT); ?></h2>
                </div>
                
                <form method="POST" class="form-container">
                    <div class="form-group">
                        <label>Product Name *</label>
                        <input type="text" name="product_name" class="form-control" 
                               value="<?php echo htmlspecialchars($product['product_name']); ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label>Category *</label>
                        <select name="category_id" class="form-control" required>
                            <option value="">Select Category</option>
                            <?php 
                            mysqli_data_seek($categories, 0);
                            while($category = mysqli_fetch_assoc($categories)): 
                            ?>
                            <option value="<?php echo $category['id']; ?>" 
                                    <?php echo ($product['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($category['category_name']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Price (TZS) *</label>
                        <input type="number" name="price" class="form-control" 
                               value="<?php echo $product['price']; ?>" 
                               step="0.01" min="0" required>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="update_product" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Product
                        </button>
                        <a href="products.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
            <?php else: ?>
            <div class="alert alert-error">
                Product not found.
            </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
