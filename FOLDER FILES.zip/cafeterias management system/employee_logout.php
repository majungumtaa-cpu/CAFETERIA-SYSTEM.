<?php
// employee_logout.php
session_start();
session_destroy();
header('Location: employee_login.php');
exit();
?>
